<!DOCTYPE html>
<html lang="zxx">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Link of CSS files -->
    <?php
    include("./assets/components/links.php")
        ?>

    <title>Lunex - Creative Agency HTML Template</title>
    <link rel="icon" type="image/png" href="assets/images/favicon.png">
</head>

<body class="bg-f8f9fd">

    <!-- Preloader -->
    <?php
    include("./assets/components/pre-loader.php")
        ?>
    <!-- End Preloader -->

    <!-- Start Navbar Area -->
    <?php
    include("./assets/components/contact-side-bar.php")
        ?>
    <!-- End Navbar Area -->

    <!-- Start Menu Popup Area -->
    <?php
    include("./assets/components/sidebar-menu.php")
        ?>
    <!-- End Menu Popup Area -->

    <!-- Start Blog Page Banner Area -->
    <div class="blog-page-banner-area">
        <div class="container">
            <div class="row">
                <div class="col-lg-5 col-md-12">
                    <div class="content">
                        <span class="sub-title d-block">
                            Our blogs
                        </span>
                        <h1 class="text-animation">
                            Digital <span>insights</span>
                        </h1>
                        <p>
                            Stay ahead with our expert digital insights, offering the latest trends and strategies to
                            help drive your success in the digital world.
                        </p>
                    </div>
                </div>
                <div class="col-lg-7 col-md-12">
                    <div class="image" data-cue="slideInUp">
                        <a href="blog-single.php" class="d-block">
                            <img src="assets/images/blogs/blog13.jpg" alt="blog-image">
                        </a>
                        <div class="d-md-flex align-items-center justify-content-between">
                            <h3 class="mb-0">
                                <a href="blog-single.php">
                                    Essential digital tools for business
                                </a>
                            </h3>
                            <a href="blog-single.php" class="link-btn d-flex align-items-center">
                                <i class="ri-arrow-right-up-line"></i>
                                <span class="d-inline-block">
                                    Read More
                                </span>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- End Blog Page Banner Area -->

    <!-- Start Blog Area -->
    <div class="blog-area ptb-150">
        <div class="container">
            <ul class="main-blog-buttons text-center ps-0 list-unstyled" data-cue="slideInUp">
                <li class="d-inline-block">
                    <a href="blog.php" class="d-block active">
                        All post
                    </a>
                </li>
                <li class="d-inline-block">
                    <a href="blog-growth.php" class="d-block">
                        Growth
                    </a>
                </li>
                <li class="d-inline-block">
                    <a href="blog-technology.php" class="d-block">
                        Technology
                    </a>
                </li>
                <li class="d-inline-block">
                    <a href="blog-social.php" class="d-block">
                        Social
                    </a>
                </li>
                <li class="d-inline-block">
                    <a href="blog-branding.php" class="d-block">
                        Branding
                    </a>
                </li>
            </ul>
            <div class="main-blogs-list" data-cues="slideInUp">
                <div class="item">
                    <div class="row align-items-center">
                        <div class="col-lg-6 col-md-6">
                            <div class="image">
                                <a href="blog-single.php" class="d-block">
                                    <img src="assets/images/blogs/blog14.jpg" alt="blog-image">
                                </a>
                                <div class="info d-flex align-items-center justify-content-between">
                                    <div class="date d-flex align-items-center">
                                        <a href="blog-single.php" class="comments d-block">
                                            02 comments
                                        </a>
                                        <span class="d-block">
                                            21 Mar 2025
                                        </span>
                                    </div>
                                    <a href="blog-single.php" class="category d-inline-block">
                                        Growth
                                    </a>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-6 col-md-6">
                            <div class="content">
                                <h2 class="fw-normal">
                                    <a href="blog-single.php">
                                        The power of storytelling in branding
                                    </a>
                                </h2>
                                <a href="blog-single.php" class="link-btn d-flex align-items-center">
                                    <i class="ri-arrow-right-up-line"></i>
                                    <span class="d-inline-block">
                                        Read More
                                    </span>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="item">
                    <div class="row align-items-center">
                        <div class="col-lg-6 col-md-6">
                            <div class="content">
                                <h2 class="fw-normal">
                                    <a href="blog-single.php">
                                        Creative campaigns that inspire action
                                    </a>
                                </h2>
                                <a href="blog-single.php" class="link-btn d-flex align-items-center">
                                    <i class="ri-arrow-right-up-line"></i>
                                    <span class="d-inline-block">
                                        Read More
                                    </span>
                                </a>
                            </div>
                        </div>
                        <div class="col-lg-6 col-md-6">
                            <div class="image">
                                <a href="blog-single.php" class="d-block">
                                    <img src="assets/images/blogs/blog15.jpg" alt="blog-image">
                                </a>
                                <div class="info d-flex align-items-center justify-content-between">
                                    <div class="date d-flex align-items-center">
                                        <a href="blog-single.php" class="comments d-block">
                                            01 comment
                                        </a>
                                        <span class="d-block">
                                            20 Feb 2025
                                        </span>
                                    </div>
                                    <a href="blog-single.php" class="category d-inline-block">
                                        Technology
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="item">
                    <div class="row align-items-center">
                        <div class="col-lg-6 col-md-6">
                            <div class="image">
                                <a href="blog-single.php" class="d-block">
                                    <img src="assets/images/blogs/blog16.jpg" alt="blog-image">
                                </a>
                                <div class="info d-flex align-items-center justify-content-between">
                                    <div class="date d-flex align-items-center">
                                        <a href="blog-single.php" class="comments d-block">
                                            03 comments
                                        </a>
                                        <span class="d-block">
                                            15 Jan 2025
                                        </span>
                                    </div>
                                    <a href="blog-single.php" class="category d-inline-block">
                                        Social
                                    </a>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-6 col-md-6">
                            <div class="content">
                                <h2 class="fw-normal">
                                    <a href="blog-single.php">
                                        The importance of ux/ui in building customer trust
                                    </a>
                                </h2>
                                <a href="blog-single.php" class="link-btn d-flex align-items-center">
                                    <i class="ri-arrow-right-up-line"></i>
                                    <span class="d-inline-block">
                                        Read More
                                    </span>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="item">
                    <div class="row align-items-center">
                        <div class="col-lg-6 col-md-6">
                            <div class="content">
                                <h2 class="fw-normal">
                                    <a href="blog-single.php">
                                        Building a strong brand online
                                    </a>
                                </h2>
                                <a href="blog-single.php" class="link-btn d-flex align-items-center">
                                    <i class="ri-arrow-right-up-line"></i>
                                    <span class="d-inline-block">
                                        Read More
                                    </span>
                                </a>
                            </div>
                        </div>
                        <div class="col-lg-6 col-md-6">
                            <div class="image">
                                <a href="blog-single.php" class="d-block">
                                    <img src="assets/images/blogs/blog17.jpg" alt="blog-image">
                                </a>
                                <div class="info d-flex align-items-center justify-content-between">
                                    <div class="date d-flex align-items-center">
                                        <a href="blog-single.php" class="comments d-block">
                                            01 comment
                                        </a>
                                        <span class="d-block">
                                            20 Feb 2025
                                        </span>
                                    </div>
                                    <a href="blog-single.php" class="category d-inline-block">
                                        Branding
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <nav class="pagination-area d-flex align-items-center justify-content-center text-center"
                data-cue="slideInUp">
                <a href="javascript:void(0);" class="prev page-numbers">
                    <i class="ri-arrow-left-s-line"></i>
                </a>
                <a href="javascript:void(0);" class="page-numbers">
                    01
                </a>
                <span class="page-numbers current" aria-current="page">
                    02
                </span>
                <a href="javascript:void(0);" class="page-numbers">
                    03
                </a>
                <a href="javascript:void(0);" class="page-numbers">
                    04
                </a>
                <a href="javascript:void(0);" class="page-numbers">
                    05
                </a>
                <a href="javascript:void(0);" class="next page-numbers">
                    <i class="ri-arrow-right-s-line"></i>
                </a>
            </nav>
        </div>
    </div>
    <!-- End Blog Area -->

    <!-- Start Footer Area -->
    <?php
    include("./assets/components/footer-two.php")
        ?>
    <!-- End Footer Area -->

    <!-- Link of JS files -->
    <?php
    include("./assets/components/script.php")
        ?>
    <!-- ========== GOOGLE TRANSLATE CONTAINER (HIDDEN) ========== -->
    <div id="google_translate_element" style="display:none;"></div>

    <script>
        // ========== GOOGLE TRANSLATE INITIALIZE ==========
        function loadGoogleTranslate() {
            new google.translate.TranslateElement({
                pageLanguage: 'en',
                includedLanguages: 'en,ur,fr,es,ar'
            }, 'google_translate_element');
        }
    </script>
    <script src="https://translate.google.com/translate_a/element.js?cb=loadGoogleTranslate"></script>

    <script>
        // ========== APPLY SAVED LANGUAGE ON EVERY PAGE ==========
        document.addEventListener("DOMContentLoaded", function () {
            const savedLang = localStorage.getItem("selectedLanguage");

            if (savedLang) {
                const checkExist = setInterval(() => {
                    const combo = document.querySelector(".goog-te-combo");
                    if (combo) {
                        combo.value = savedLang;
                        combo.dispatchEvent(new Event("change"));
                        clearInterval(checkExist);
                    }
                }, 400);
            }
        });
    </script>

</body>

</html>