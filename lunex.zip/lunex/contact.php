<!DOCTYPE html>
<html lang="zxx">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Database files Setup Starts -->
    <?php
    include("./assets/database/config.php")
        ?>

    <!-- Link of CSS files -->
    <?php
    include("./assets/components/links.php")
        ?>

    <title>Lunex - Creative Agency HTML Template</title>
    <link rel="icon" type="image/png" href="assets/images/favicon.png">
</head>

<body>

    <!-- Preloader -->
    <?php
    include("./assets/components/pre-loader.php")
        ?>
    <!-- End Preloader -->

    <!-- Start Navbar Area -->
    <?php
    include("./assets/components/contact-side-bar.php")
        ?>
    <!-- End Navbar Area -->
    <!-- Page Banner Area -->
    <div class="page_banner_area">
        <div class="container">
            <div class="page_banner_content text-center">
                <span class="sub_title d-block fw-medium">
                    Contact Us
                </span>
                <h1 class="mb-0 text_animation">
                    Thinking of Starting a New Project?
                </h1>
            </div>
        </div>
    </div>
    <!-- End Page Banner Area -->

    <!-- Contact Area -->
    <div class="contact_area ptb-150">
        <div class="container">
            <div class="row gx-0" data-cue="slideInUp">
                <div class="col-lg-6 order-2 order-lg-1">
                    <div class="contact_image position-relative"
                        style="background-image: url(assets/images/girl_with_laptop.jpg);">
                        <img src="assets/images/girl_with_laptop.jpg" alt="girl_with_laptop">
                        <div class="text_box">
                            <p class="text-white fw-medium">
                                “ Simplifying website development, this software makes managing your online presence
                                hassle-free. “
                            </p>
                            <h3 class="text-white fw-semibold">
                                Apollo Maddox
                            </h3>
                            <span class="d-block text-white">
                                Founder & CEO
                            </span>
                        </div>
                    </div>
                </div>
                <div class="col-lg-6 order-1 order-lg-2">
                    <div class="contact_form">
                        <p>
                            Have questions or feedback? Drop us a message below, and we’ll get back to you quickly.
                        </p>
                        <form id="contactForm" action="./assets/Backend/save_contact.php" method="POST">
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <input type="text" name="full_name" class="form-control" placeholder="Full Name"
                                            required>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <input type="email" name="email" class="form-control" placeholder="Your Email"
                                            required>
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <select class="form-select" name="service_type" required>
                                            <option value="">Select</option>
                                            <option value="Web design">Web design</option>
                                            <option value="Branding & identity">Branding & identity</option>
                                            <option value="Digital marketing">Digital marketing</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <textarea name="message" class="form-control" placeholder="Message"
                                            required></textarea>
                                    </div>
                                </div>
                                <div class="col-md-12 text-center">
                                    <button type="submit" class="btn primary_btn text-capitalize d-block w-100">
                                        Send Message
                                    </button>
                                    <p>Or drop us a message via email.</p>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- End Contact Area -->

    <!-- Reach Us Area -->
    <div class="reach_us_area pb-125">
        <div class="container">
            <div class="section_title text-center mx-auto">
                <h2 class="mb-0 text_animation fw-bold">
                    Other Ways to Reach Us
                </h2>
            </div>
            <div class="row justify-content-center" data-cues="slideInUp" data-group="reach_us_list">
                <div class="col-lg-3 col-sm-6">
                    <div class="reach_us_box text-center">
                        <div class="icon d-flex align-items-center justify-content-center">
                            <i class="ri-map-pin-line"></i>
                        </div>
                        <h3>
                            Our Office
                        </h3>
                        <p>
                            Nenuya Centre Elia Street, New York, USA
                        </p>
                        <a href="#" target="_blank" class="details_link_btn d-inline-block position-relative fw-medium">
                            Visit Us <i class="ri-arrow-right-long-line"></i>
                        </a>
                    </div>
                </div>
                <div class="col-lg-3 col-sm-6">
                    <div class="reach_us_box text-center">
                        <div class="icon d-flex align-items-center justify-content-center">
                            <i class="ri-message-2-line"></i>
                        </div>
                        <h3>
                            Via Chat
                        </h3>
                        <p>
                            Instant solutions at your fingertips.
                        </p>
                        <a href="contact.php" class="details_link_btn d-inline-block position-relative fw-medium">
                            Let's Chat <i class="ri-arrow-right-long-line"></i>
                        </a>
                    </div>
                </div>
                <div class="col-lg-3 col-sm-6">
                    <div class="reach_us_box text-center">
                        <div class="icon d-flex align-items-center justify-content-center">
                            <i class="ri-question-line"></i>
                        </div>
                        <h3>
                            Report Issue
                        </h3>
                        <p>
                            Access premium support services.
                        </p>
                        <a href="contact.php" class="details_link_btn d-inline-block position-relative fw-medium">
                            Send Report <i class="ri-arrow-right-long-line"></i>
                        </a>
                    </div>
                </div>
                <div class="col-lg-3 col-sm-6">
                    <div class="reach_us_box text-center">
                        <div class="icon d-flex align-items-center justify-content-center">
                            <i class="ri-group-2-line"></i>
                        </div>
                        <h3>
                            Our Community
                        </h3>
                        <p>
                            Create meaningful connections with users.
                        </p>
                        <a href="contact.php" class="details_link_btn d-inline-block position-relative fw-medium">
                            Join Us <i class="ri-arrow-right-long-line"></i>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- End Reach Us Area -->

    <!-- FAQ Area -->
    <div class="faq_area">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-lg-6">
                    <div class="faq_content">
                        <div class="sub_title d-inline-block style_two">
                            <span class="d-flex align-items-center text-uppercase">
                                FAQ
                                <img src="assets/images/icons/white_arrow_long_right.svg" alt="white_arrow_long_right">
                            </span>
                        </div>
                        <h2 class="text_animation fw-bold">
                            Have Questions? We’ve got Answers
                        </h2>
                        <div class="accordion style_two" id="faqAccordion" data-cues="slideInUp"
                            data-group="faq_content">
                            <div class="accordion-item rounded-0 bg-transparent">
                                <button
                                    class="accordion-button d-block text-start p-0 fw-semibold bg-transparent shadow-none"
                                    type="button" data-bs-toggle="collapse" data-bs-target="#collapseOne"
                                    aria-expanded="true" aria-controls="collapseOne">
                                    What is the difference between SEO and PPC?
                                </button>
                                <div id="collapseOne" class="accordion-collapse collapse show"
                                    data-bs-parent="#faqAccordion">
                                    <div class="accordion-body px-0 pb-0">
                                        <p>
                                            Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod
                                            tempor incidid unt ut labo magna.
                                        </p>
                                    </div>
                                </div>
                            </div>
                            <div class="accordion-item rounded-0 bg-transparent">
                                <button
                                    class="accordion-button d-block text-start p-0 fw-semibold bg-transparent shadow-none collapsed"
                                    type="button" data-bs-toggle="collapse" data-bs-target="#collapseTwo"
                                    aria-expanded="false" aria-controls="collapseTwo">
                                    What is included in your SEO services?
                                </button>
                                <div id="collapseTwo" class="accordion-collapse collapse"
                                    data-bs-parent="#faqAccordion">
                                    <div class="accordion-body px-0 pb-0">
                                        <p>
                                            Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod
                                            tempor incidid unt ut labo magna.
                                        </p>
                                    </div>
                                </div>
                            </div>
                            <div class="accordion-item rounded-0 bg-transparent">
                                <button
                                    class="accordion-button d-block text-start p-0 fw-semibold bg-transparent shadow-none collapsed"
                                    type="button" data-bs-toggle="collapse" data-bs-target="#collapseThree"
                                    aria-expanded="false" aria-controls="collapseThree">
                                    Do you provide support after the campaign ends?
                                </button>
                                <div id="collapseThree" class="accordion-collapse collapse"
                                    data-bs-parent="#faqAccordion">
                                    <div class="accordion-body px-0 pb-0">
                                        <p>
                                            Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod
                                            tempor incidid unt ut labo magna.
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="faq_image position-relative z-1" data-cue="slideInUp">
                        <img src="assets/images/faq.jpg" alt="faq-image">
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- End FAQ Area -->

    <!-- ========== ALERT BOX ========== -->
    <div id="alertBox" style="
    display: none;
    padding: 12px 20px;
    margin-top: 15px;
    border-radius: 6px;
    font-weight: 500;
    text-align: center;
"></div>


    <!-- Footer Area -->
    <?php
    include("./assets/components/contact-footer.php")
        ?>
    <!-- End Footer Area -->

    <!-- Back to Top -->
    <?php
    include("./assets/components/back-to-top.php")
        ?>
    <!-- End Back to Top -->

    <!-- Link of JS files -->
    <?php
    include("./assets/components/script.php")
        ?>

    <script>
        // ========== HANDLE CONTACT FORM SUBMISSION ==========
        document.getElementById('contactForm').addEventListener('submit', function (e) {
            e.preventDefault(); // PREVENT PAGE RELOAD

            const formData = new FormData(this);

            // ========== SEND DATA TO BACKEND ==========
            fetch('./assets/backend/save_contact.php', {
                method: 'POST',
                body: formData
            })
                .then(res => res.json())
                .then(data => {
                    const alertBox = document.getElementById('alertBox');

                    // ========== SHOW ALERT BOX ==========
                    alertBox.style.display = 'block';
                    alertBox.style.transition = 'all 0.5s ease';
                    alertBox.textContent = data.message;


                    if (data.status === 'success') {
                        alertBox.style.backgroundColor = '#d4edda'; // GREEN BACKGROUND
                        alertBox.style.color = '#155724';
                        this.reset(); // CLEAR FORM FIELDS
                    } else {
                        alertBox.style.backgroundColor = '#f8d7da'; // RED BACKGROUND
                        alertBox.style.color = '#721c24';
                    }

                    // ========== FADE OUT ALERT AFTER 3 SECONDS ==========
                    setTimeout(() => {
                        alertBox.style.opacity = '0';
                        setTimeout(() => {
                            alertBox.style.display = 'none';
                            alertBox.style.opacity = '1';
                        }, 500);
                    }, 3000);
                })
                .catch(() => {
                    alertBox.style.display = 'block';
                    alertBox.style.backgroundColor = '#f8d7da';
                    alertBox.style.color = '#721c24';
                    alertBox.textContent = 'Something went wrong. Please try again.';
                });
        });
    </script>
    <!-- ========== GOOGLE TRANSLATE CONTAINER (HIDDEN) ========== -->
    <div id="google_translate_element" style="display:none;"></div>

    <script>
        // ========== GOOGLE TRANSLATE INITIALIZE ==========
        function loadGoogleTranslate() {
            new google.translate.TranslateElement({
                pageLanguage: 'en',
                includedLanguages: 'en,ur,fr,es,ar'
            }, 'google_translate_element');
        }
    </script>
    <script src="https://translate.google.com/translate_a/element.js?cb=loadGoogleTranslate"></script>

    <script>
        // ========== APPLY SAVED LANGUAGE ON EVERY PAGE ==========
        document.addEventListener("DOMContentLoaded", function () {
            const savedLang = localStorage.getItem("selectedLanguage");

            if (savedLang) {
                const checkExist = setInterval(() => {
                    const combo = document.querySelector(".goog-te-combo");
                    if (combo) {
                        combo.value = savedLang;
                        combo.dispatchEvent(new Event("change"));
                        clearInterval(checkExist);
                    }
                }, 400);
            }
        });
    </script>


</body>

</html>