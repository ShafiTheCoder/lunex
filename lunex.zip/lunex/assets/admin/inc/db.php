<?php
// ========== DATABASE CONNECTOR - TRIES COMMON LOCATIONS ==========
/* ========== UPDATE PATHS BELOW IF YOUR config.php IS IN A DIFFERENT LOCATION ========== */
$db_config_paths = [
    __DIR__ . '/../../assets/database/config.php',
    __DIR__ . '/../../database/config.php',
    __DIR__ . '/../../assets/database/config.php',
    __DIR__ . '/../../../database/config.php'
];

$found = false;
foreach ($db_config_paths as $p) {
    if (file_exists($p)) {
        require_once $p;
        $found = true;
        break;
    }
}

if (!$found) {
    die("DATABASE CONFIG NOT FOUND. EDIT admin/inc/db.php AND POINT TO YOUR config.php");
}

// ========== EXPECTS $conn TO BE CREATED BY config.php ==========
if (!isset($conn) || !($conn instanceof mysqli)) {
    die("DATABASE CONNECTION (\$conn) NOT INITIALIZED IN config.php");
}

// ========== ENSURE UTF8 ==========
$conn->set_charset("utf8mb4");

// ========== ENSURE DEFAULT ADMIN EXISTS ==========
function ensure_default_admin($conn) {
    $default_email = 'obaid123@gmail.com';
    $default_password = 'hello world';
    $stmt = $conn->prepare("SELECT id FROM admins WHERE email = ? LIMIT 1");
    $stmt->bind_param("s", $default_email);
    $stmt->execute();
    $stmt->store_result();
    if ($stmt->num_rows === 0) {
        $hashed = password_hash($default_password, PASSWORD_DEFAULT);
        $ins = $conn->prepare("INSERT INTO admins (email, password, name) VALUES (?, ?, ?)");
        $name = 'Default Admin';
        $ins->bind_param("sss", $default_email, $hashed, $name);
        $ins->execute();
        $ins->close();
    }
    $stmt->close();
}
ensure_default_admin($conn);
