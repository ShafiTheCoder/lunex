<?php
// ========== AUTH HELPERS ==========
if (session_status() === PHP_SESSION_NONE) session_start();

function require_login() {
    if (empty($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
        header("Location: login.php");
        exit;
    }
}

function admin_login($admin_row) {
    session_regenerate_id(true);
    $_SESSION['admin_logged_in'] = true;
    $_SESSION['admin_id'] = $admin_row['id'];
    $_SESSION['admin_email'] = $admin_row['email'];
    $_SESSION['admin_name'] = $admin_row['name'] ?? $admin_row['email'];
}

function admin_logout() {
    $_SESSION = [];
    if (ini_get("session.use_cookies")) {
        setcookie(session_name(), '', time() - 42000);
    }
    session_destroy();
}
