<?php
// ========== ADMIN DASHBOARD PAGE (PRESENTATION ONLY) ==========
// ========== USES EXISTING BACKEND (INC/DB.PHP, INC/AUTH.PHP, INC/CSRF.PHP, ACTIONS.PHP) ==========
require_once __DIR__ . '/inc/db.php';
require_once __DIR__ . '/inc/auth.php';
require_once __DIR__ . '/inc/csrf.php';

if (session_status() === PHP_SESSION_NONE)
    session_start();
require_login(); // REDIRECTS TO login.php IF NOT AUTHENTICATED

$csrf = csrf_generate();

// ========== FETCH CONTACT MESSAGES ==========
$contacts = [];
$cm_stmt = $conn->prepare("SELECT id, full_name, email, service_type, message, created_at FROM contact_messages ORDER BY created_at DESC");
$cm_stmt->execute();
$cm_res = $cm_stmt->get_result();
if ($cm_res)
    $contacts = $cm_res->fetch_all(MYSQLI_ASSOC);
$cm_stmt->close();

// ========== FETCH ORDERS ==========
$pending = [];
$done = [];
$o_stmt = $conn->prepare("SELECT id, customer_name, customer_email, customer_contact, description, price, assigned_to, category, status, created_at FROM orders ORDER BY created_at DESC");
$o_stmt->execute();
$o_res = $o_stmt->get_result();
if ($o_res) {
    while ($r = $o_res->fetch_assoc()) {
        if ($r['status'] === 'pending')
            $pending[] = $r;
        else
            $done[] = $r;
    }
}
$o_stmt->close();
?>
<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>Admin • Dashboard</title>

    <!-- ========== CSS ========== -->
    <link rel="stylesheet" href="assets/css/style.css">

    <!-- ========== ICONS & FONTS ========== -->
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/remixicon@3.2.0/fonts/remixicon.css">

    <!-- ========== SCRIPTS (GSAP + OPTIONAL JQUERY) ========== -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.2/gsap.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.2/ScrollTrigger.min.js"></script>
    <script src="../assets/js/jquery.min.js"></script>
</head>

<body>

    <!-- ========== SIDEBAR (FIXED) ==========> -->
    <aside class="sidebar" id="sidebar">
        <div class="brand">
            <div class="brand-name">LUNEX</div>
        </div>

        <nav class="nav">
            <button class="nav-item active" data-tab="messages"><i class="ri-mail-line"></i> Messages</button>
            <button class="nav-item" data-tab="create"><i class="ri-add-line"></i> Create Order</button>
            <button class="nav-item" data-tab="pending"><i class="ri-time-line"></i> Pending Orders <span
                    class="badge"><?php echo count($pending); ?></span></button>
            <button class="nav-item" data-tab="done"><i class="ri-check-line"></i> Completed Orders <span
                    class="badge"><?php echo count($done); ?></span></button>
        </nav>

        <div class="sidebar-footer">
            <div class="signed">Signed in
                as<br><strong><?php echo htmlspecialchars($_SESSION['admin_name'] ?? $_SESSION['admin_email']); ?></strong>
            </div>
            <div class="footer-actions">
                <a class="btn-quiet" href="logout.php"><i class="ri-logout-box-line"></i> Logout</a>
            </div>
        </div>
    </aside>

    <!-- ========== MAIN CONTENT ==========> -->
    <main class="main">
        <header class="topbar">
            <button id="toggleSidebar" class="toggle-btn"><i class="ri-menu-line"></i></button>
            <h1 class="page-title">Dashboard</h1>
            <div class="top-actions">
                <input id="globalSearch" class="search-input" placeholder="Search messages & orders..." />
            </div>
        </header>

        <section class="content-area">
            <!-- ========== STATS ROW ==========> -->
            <div class="stats-row">
                <div class="stat-card">
                    <div class="stat-label">Messages</div>
                    <div class="stat-value"><?php echo count($contacts); ?></div>
                </div>
                <div class="stat-card">
                    <div class="stat-label">Pending Orders</div>
                    <div class="stat-value"><?php echo count($pending); ?></div>
                </div>
                <div class="stat-card">
                    <div class="stat-label">Completed Orders</div>
                    <div class="stat-value"><?php echo count($done); ?></div>
                </div>
            </div>

            <!-- ========== TABS PANELS ==========> -->
            <div class="tabs">

                <!-- TAB: MESSAGES -->
                <div class="tab-panel active" id="tab-messages">
                    <div class="panel-head">
                        <h2>Contact Messages</h2>
                    </div>
                    <div class="table-container">
                        <table id="contactsTable">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Name</th>
                                    <th>Email</th>
                                    <th>Service</th>
                                    <th>Message</th>
                                    <th>Created</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if (!empty($contacts)):
                                    foreach ($contacts as $c): ?>
                                        <tr>
                                            <td><?php echo (int) $c['id']; ?></td>
                                            <td><?php echo htmlspecialchars($c['full_name']); ?></td>
                                            <td><?php echo htmlspecialchars($c['email']); ?></td>
                                            <td><?php echo htmlspecialchars($c['service_type']); ?></td>
                                            <td class="msg-cell"><?php echo htmlspecialchars($c['message']); ?></td>
                                            <td><?php echo htmlspecialchars($c['created_at']); ?></td>
                                        </tr>
                                    <?php endforeach; else: ?>
                                    <tr>
                                        <td colspan="6" class="text-center muted">No messages found.</td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>

                <!-- TAB: CREATE -->
                <div class="tab-panel" id="tab-create">
                    <div class="panel-head">
                        <h2>Create Order</h2>
                    </div>
                    <form id="createOrderForm" class="form-card">
                        <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($csrf); ?>">
                        <input type="hidden" name="action" value="create_order">
                        <div class="form-grid">
                            <div class="form-group"><label>Customer Name</label><input name="name" required></div>
                            <div class="form-group"><label>Email</label><input name="email" type="email" required></div>
                            <div class="form-group"><label>Contact</label><input name="contact"></div>
                            <div class="form-group"><label>Price</label><input name="price" type="number" step="0.01"
                                    value="0.00"></div>
                            <div class="form-group"><label>Assign To</label><input name="assigned_to"></div>
                            <div class="form-group"><label>Category</label><input name="category"></div>
                            <div class="form-group full"><label>Description</label><textarea name="description"
                                    rows="4"></textarea></div>
                        </div>
                        <div class="form-actions">
                            <button type="submit" class="btn-primary">Create Order</button>
                            <div id="createResp" class="form-note"></div>
                        </div>
                    </form>
                </div>

                <!-- TAB: PENDING -->
                <div class="tab-panel" id="tab-pending">
                    <div class="panel-head">
                        <h2>Pending Orders</h2>
                    </div>
                    <div class="table-container">
                        <table id="pendingTable">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Name</th>
                                    <th>Email</th>
                                    <th>Contact</th>
                                    <th>Price</th>
                                    <th>Assigned</th>
                                    <th>Category</th>
                                    <th>Created</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if (!empty($pending)):
                                    foreach ($pending as $p): ?>
                                        <tr>
                                            <td><?php echo (int) $p['id']; ?></td>
                                            <td><?php echo htmlspecialchars($p['customer_name']); ?></td>
                                            <td><?php echo htmlspecialchars($p['customer_email']); ?></td>
                                            <td><?php echo htmlspecialchars($p['customer_contact']); ?></td>
                                            <td><?php echo htmlspecialchars($p['price']); ?></td>
                                            <td><?php echo htmlspecialchars($p['assigned_to']); ?></td>
                                            <td><?php echo htmlspecialchars($p['category']); ?></td>
                                            <td><?php echo htmlspecialchars($p['created_at']); ?></td>
                                            <td><button class="btn-sm btn-success mark-done"
                                                    data-id="<?php echo (int) $p['id']; ?>">Mark Done</button></td>
                                        </tr>
                                    <?php endforeach; else: ?>
                                    <tr>
                                        <td colspan="9" class="text-center muted">No pending orders.</td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>

                <!-- TAB: DONE -->
                <div class="tab-panel" id="tab-done">
                    <div class="panel-head">
                        <h2>Completed Orders</h2>
                    </div>
                    <div class="table-container">
                        <table id="doneTable">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Name</th>
                                    <th>Email</th>
                                    <th>Contact</th>
                                    <th>Price</th>
                                    <th>Assigned</th>
                                    <th>Category</th>
                                    <th>Created</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if (!empty($done)):
                                    foreach ($done as $d): ?>
                                        <tr>
                                            <td><?php echo (int) $d['id']; ?></td>
                                            <td><?php echo htmlspecialchars($d['customer_name']); ?></td>
                                            <td><?php echo htmlspecialchars($d['customer_email']); ?></td>
                                            <td><?php echo htmlspecialchars($d['customer_contact']); ?></td>
                                            <td><?php echo htmlspecialchars($d['price']); ?></td>
                                            <td><?php echo htmlspecialchars($d['assigned_to']); ?></td>
                                            <td><?php echo htmlspecialchars($d['category']); ?></td>
                                            <td><?php echo htmlspecialchars($d['created_at']); ?></td>
                                            <td><button class="btn-sm btn-warn mark-pending"
                                                    data-id="<?php echo (int) $d['id']; ?>">Mark Pending</button></td>
                                        </tr>
                                    <?php endforeach; else: ?>
                                    <tr>
                                        <td colspan="9" class="text-center muted">No completed orders.</td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>

            </div> <!-- END TABS -->
        </section>
    </main>

    <!-- ========== JS ========== -->
    <script src="assets/js/app.js"></script>
</body>

</html>