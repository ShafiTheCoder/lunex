<?php
// ========== ACTIONS ENDPOINT (CREATE ORDER, TOGGLE STATUS) ==========
require_once __DIR__ . '/inc/db.php';
require_once __DIR__ . '/inc/csrf.php';
require_once __DIR__ . '/inc/auth.php';

if (session_status() === PHP_SESSION_NONE) session_start();
require_login();

header('Content-Type: application/json; charset=utf-8');

$action = $_POST['action'] ?? '';

if ($action === 'create_order') {
    if (!csrf_check($_POST['csrf_token'] ?? '')) {
        echo json_encode(['status'=>'error','message'=>'Invalid CSRF token']); exit;
    }
    $name = trim($_POST['name'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $contact = trim($_POST['contact'] ?? '');
    $description = trim($_POST['description'] ?? '');
    $price = floatval($_POST['price'] ?? 0);
    $assigned_to = trim($_POST['assigned_to'] ?? '');
    $category = trim($_POST['category'] ?? '');

    if (!$name || !$email) {
        echo json_encode(['status'=>'error','message'=>'Name and email required']); exit;
    }

    $stmt = $conn->prepare("INSERT INTO orders (customer_name, customer_email, customer_contact, description, price, assigned_to, category, status) VALUES (?, ?, ?, ?, ?, ?, ?, 'pending')");
    $stmt->bind_param("ssssdss", $name, $email, $contact, $description, $price, $assigned_to, $category);

    if ($stmt->execute()) {
        echo json_encode(['status'=>'success','message'=>'Order created']);
    } else {
        echo json_encode(['status'=>'error','message'=>$stmt->error]);
    }
    $stmt->close();
    exit;
}

if ($action === 'toggle_status') {
    if (!csrf_check($_POST['csrf_token'] ?? '')) {
        echo json_encode(['status'=>'error','message'=>'Invalid CSRF token']); exit;
    }
    $id = intval($_POST['id'] ?? 0);
    $new = ($_POST['new_status'] === 'done') ? 'done' : 'pending';
    if ($id <= 0) {
        echo json_encode(['status'=>'error','message'=>'Invalid id']); exit;
    }
    $stmt = $conn->prepare("UPDATE orders SET status = ? WHERE id = ?");
    $stmt->bind_param("si", $new, $id);
    if ($stmt->execute()) {
        echo json_encode(['status'=>'success','message'=>'Status updated']);
    } else {
        echo json_encode(['status'=>'error','message'=>$stmt->error]);
    }
    $stmt->close();
    exit;
}

echo json_encode(['status'=>'error','message'=>'Action not recognized']);
exit;
