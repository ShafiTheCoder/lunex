// ========== ADMIN UI SCRIPT ==========
// ========== HANDLES TAB SWITCH, SEARCH, FORM SUBMIT, STATUS TOGGLE, BASIC GSAP ANIMS ==========
document.addEventListener('DOMContentLoaded', function () {
  // ========== ELEMENTS ==========
  const navItems = document.querySelectorAll('.nav .nav-item');
  const panels = document.querySelectorAll('.tab-panel');
  const toggleBtn = document.getElementById('toggleSidebar');
  const sidebar = document.getElementById('sidebar') || document.querySelector('.sidebar');
  const searchInput = document.getElementById('globalSearch');

  // ========== TAB SWITCH ==========
  function showTab(name) {
    panels.forEach(p => {
      if (p.id === 'tab-' + name) {
        p.classList.add('active');
        gsap.fromTo(p, {opacity:0, y:8}, {opacity:1, y:0, duration:0.45, ease:'power3.out'});
      } else {
        p.classList.remove('active');
      }
    });
    navItems.forEach(n => n.classList.toggle('active', n.dataset.tab === name));
  }

  navItems.forEach(btn => {
    btn.addEventListener('click', function () {
      const tab = this.dataset.tab;
      showTab(tab);
    });
  });

  // ========== SIDEBAR TOGGLE (SMALL SCREENS) ==========
  if (toggleBtn) {
    toggleBtn.addEventListener('click', function () {
      if (sidebar.style.transform === 'translateX(-120%)') {
        sidebar.style.transform = '';
      } else {
        sidebar.style.transform = 'translateX(-120%)';
      }
    });
  }

  // ========== GLOBAL SEARCH ==========
  if (searchInput) {
    searchInput.addEventListener('input', function () {
      const q = this.value.trim().toLowerCase();
      document.querySelectorAll('table tbody tr').forEach(row => {
        const visible = Array.from(row.cells).some(td => td.textContent.toLowerCase().includes(q));
        row.style.display = visible ? '' : 'none';
      });
    });
  }

  // ========== CREATE ORDER FORM (AJAX) ==========
  const createForm = document.getElementById('createOrderForm');
  if (createForm) {
    createForm.addEventListener('submit', function (e) {
      e.preventDefault();
      const btn = createForm.querySelector('.btn-primary') || createForm.querySelector('button[type="submit"]');
      btn.disabled = true; btn.textContent = 'Creating...';
      const data = new FormData(createForm);
      fetch('actions.php', { method: 'POST', body: data })
        .then(r => r.json())
        .then(resp => {
          btn.disabled = false; btn.textContent = 'Create Order';
          const note = document.getElementById('createResp');
          if (resp.status === 'success') {
            note.innerHTML = '<span style="color:green;">'+resp.message+'</span>';
            setTimeout(()=> location.reload(), 700);
          } else {
            note.innerHTML = '<span style="color:#d9534f;">'+(resp.message||'Failed')+'</span>';
          }
        }).catch(()=> {
          btn.disabled = false; btn.textContent = 'Create Order';
          document.getElementById('createResp').innerHTML = '<span style="color:#d9534f;">Request failed</span>';
        });
    });
  }

  // ========== TOGGLE ORDER STATUS ==========
  function toggleStatus(id, newStatus) {
    const tokenEl = document.querySelector('input[name="csrf_token"]');
    const token = tokenEl ? tokenEl.value : '';
    const fd = new FormData();
    fd.append('action','toggle_status');
    fd.append('id', id);
    fd.append('new_status', newStatus);
    fd.append('csrf_token', token);
    fetch('actions.php', { method:'POST', body: fd })
      .then(r => r.json())
      .then(resp => {
        if (resp.status === 'success') location.reload();
        else alert(resp.message || 'Update failed');
      }).catch(()=> alert('Network error'));
  }

  document.addEventListener('click', function (e) {
    if (e.target.matches('.mark-done')) toggleStatus(e.target.dataset.id, 'done');
    if (e.target.matches('.mark-pending')) toggleStatus(e.target.dataset.id, 'pending');
  });

  // ========== INITIAL ANIMATIONS ==========
  gsap.from('.brand-logo, .brand-name', { opacity:0, y:-6, duration:0.6, stagger:0.04 });
  gsap.from('.stat-card', { opacity:0, y:8, duration:0.7, stagger:0.06 });
  // SHOW DEFAULT TAB (messages)
  showTab('messages');
});
