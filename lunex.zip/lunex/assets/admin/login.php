<?php
// ========== ADMIN LOGIN PAGE ==========
require_once __DIR__ . '/inc/db.php';
require_once __DIR__ . '/inc/csrf.php';
require_once __DIR__ . '/inc/auth.php';

if (session_status() === PHP_SESSION_NONE) session_start();
if (!empty($_SESSION['admin_logged_in'])) {
    header('Location: index.php'); exit;
}

$errors = [];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrf_check($_POST['csrf_token'] ?? '')) {
        $errors[] = "Invalid CSRF token.";
    } else {
        $email = trim($_POST['email'] ?? '');
        $password = trim($_POST['password'] ?? '');
        if (empty($email) || empty($password)) {
            $errors[] = "Email and password are required.";
        } else {
            $stmt = $conn->prepare("SELECT id, email, password, name FROM admins WHERE email = ? LIMIT 1");
            $stmt->bind_param("s", $email);
            $stmt->execute();
            $res = $stmt->get_result();
            if ($res && $res->num_rows === 1) {
                $row = $res->fetch_assoc();
                if (password_verify($password, $row['password'])) {
                    admin_login($row);
                    header('Location: index.php'); exit;
                } else {
                    $errors[] = "Invalid credentials.";
                }
            } else {
                $errors[] = "Invalid credentials.";
            }
            $stmt->close();
        }
    }
}
$token = csrf_generate();
?>
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>Admin Login — Lunex</title>
  <link rel="stylesheet" href="../assets/css/bootstrap.min.css">
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600;700&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="assets/css/style.css">
</head>
<body class="login-page">
  <div class="center-wrap">
    <div class="login-card glass">
      <div class="login-top">
        <img src="../assets/images/logo.svg" alt="logo" class="logo">
        <h2>ADMIN LOGIN</h2>
        <p class="muted">Sign in to manage messages & orders</p>
      </div>

      <?php if (!empty($errors)): ?>
        <div class="alert alert-danger"><?php echo implode('<br>', array_map('htmlspecialchars', $errors)); ?></div>
      <?php endif; ?>

      <form method="post" class="login-form">
        <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($token); ?>">
        <div class="form-group">
          <label>Email</label>
          <input name="email" class="form-control" type="email" value="<?php echo htmlspecialchars($_POST['email'] ?? ''); ?>" required>
        </div>
        <div class="form-group">
          <label>Password</label>
          <input name="password" class="form-control" type="password" required>
        </div>
        <div class="form-group">
          <button class="btn btn-primary btn-block">Sign In</button>
        </div>
        <div class="small muted text-center">Default admin: <strong>obaid123@gmail.com</strong> / <strong>hello world</strong></div>
      </form>
    </div>
  </div>

  <script src="../assets/js/jquery.min.js"></script>
  <script src="assets/js/app.js"></script>
  <script>
    // ========== GSAP LOGIN ENTRANCE ==========
    if (window.gsap) {
      gsap.from('.login-card',{duration:0.8, y:30, opacity:0, ease:'power3.out'});
      gsap.from('.login-top h2',{duration:0.7, y:-10, opacity:0, delay:0.1});
    }
  </script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.2/gsap.min.js"></script>
</body>
</html>
