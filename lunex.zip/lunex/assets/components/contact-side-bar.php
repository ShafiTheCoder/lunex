<div class="navbar-area style-four top-0 start-0 end-0 h-auto">
    <div class="container-fluid">
        <nav class="navbar p-0 navbar-expand-lg">
            <a class="navbar-brand" href="index.php">
                <img src="assets/images/logo.svg" alt="logo" class="black-logo">
                <img src="assets/images/white-logo.svg" class="d-none" alt="logo">
            </a>
            <button class="navbar-toggler" type="button">
                <span class="burger-menu">
                    <span class="top-bar"></span>
                    <span class="middle-bar"></span>
                    <span class="bottom-bar"></span>
                </span>
            </button>
            <div class="collapse navbar-collapse">
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <a href="./index-3.php" class="dropdown-toggle nav-link">
                            Home
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="./works.php" class="dropdown-toggle nav-link">
                            Works
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="./about.php" class="dropdown-toggle nav-link">
                            About us
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="./services.php" class="dropdown-toggle nav-link">
                            Services
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="./blog.php" class="dropdown-toggle nav-link">
                            Blogs
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="./contact.php" class="dropdown-toggle nav-link active">
                            Contacts
                        </a>
                    </li>
                </ul>
                <div class="others-option d-flex align-items-center">
                    <button type="button" class="light-dark-btn d-inline-block p-0 bg-transparent border-0 lh-1"
                        id="light-dark-btn">
                        <i class="ri-sun-line"></i>
                    </button>
                    <a href="contact.php" class="link-btn fw-semibold d-flex align-items-center">
                        <span>
                            <img src="assets/images/icons/white-right-top-arrow.svg" alt="right-top-arrow">
                        </span>
                        Talk to Us
                    </a>
                </div>
            </div>
        </nav>
    </div>
</div>