<!-- Back to Top -->
<div class="back-to-top rounded-circle position-fixed text-center rounded-circle">
    <img src="assets/images/icons/up-arrow.svg" alt="up-arrow">
    <img src="assets/images/icons/white-up-arrow.svg" alt="white-up-arrow">
</div>
<!-- End Back to Top -->