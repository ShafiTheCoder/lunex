<!-- Start Menu Popup Area -->
<div class="menu-popup-area position-fixed start-0 end-0 top-0 bottom-0">
    <div class="d-table">
        <div class="d-table-cell">
            <div class="container">
                <div class="row align-items-center">
                    <div class="col-lg-8 col-md-12">
                        <div class="meanu-popup-nav">
                            <div class="accordion" id="navbarAccordion">
                                <div class="accordion-item border-0 rounded-0 bg-transparent">
                                    <button
                                        class="accordion-button d-block w-100 shadow-none position-relative text-decoration-none bg-transparent fw-semibold collapsed active"
                                        type="button" href="index-3.php" data-bs-toggle="collapse"
                                        data-bs-target="#navbarCollapseOne" aria-expanded="false"
                                        aria-controls="navbarCollapseOne">
                                        <a href="./index-3.php">Home</a>
                                    </button>
                                </div>
                                <div class="accordion-item border-0 rounded-0 bg-transparent">
                                    <button
                                        class="accordion-button d-block w-100 shadow-none position-relative text-decoration-none bg-transparent fw-semibold collapsed"
                                        type="button" data-bs-toggle="collapse" data-bs-target="#navbarCollapseTwo"
                                        aria-expanded="false" aria-controls="navbarCollapseTwo">
                                        Works
                                    </button>
                                </div>
                                <div class="accordion-item border-0 rounded-0 bg-transparent">
                                    <button
                                        class="accordion-button d-block w-100 shadow-none position-relative text-decoration-none bg-transparent fw-semibold collapsed"
                                        type="button" data-bs-toggle="collapse" data-bs-target="#navbarCollapseThree"
                                        aria-expanded="false" aria-controls="navbarCollapseThree">
                                        Services
                                    </button>
                                </div>
                                <div class="accordion-item border-0 rounded-0 bg-transparent">
                                    <button
                                        class="accordion-button d-block w-100 shadow-none position-relative text-decoration-none bg-transparent fw-semibold collapsed"
                                        type="button" data-bs-toggle="collapse" data-bs-target="#navbarCollapseFour"
                                        aria-expanded="false" aria-controls="navbarCollapseFour">
                                        About us
                                    </button>
                                </div>
                                <div class="accordion-item border-0 rounded-0 bg-transparent">
                                    <button
                                        class="accordion-button d-block w-100 shadow-none position-relative text-decoration-none bg-transparent fw-semibold collapsed"
                                        type="button" data-bs-toggle="collapse" data-bs-target="#navbarCollapseFive"
                                        aria-expanded="false" aria-controls="navbarCollapseFive">
                                        Blogs
                                    </button>
                                </div>
                                <div class="accordion-item border-0 rounded-0 bg-transparent">
                                    <button
                                        class="accordion-button d-block w-100 shadow-none position-relative text-decoration-none bg-transparent fw-semibold collapsed"
                                        type="button" data-bs-toggle="collapse" data-bs-target="#navbarCollapseSix"
                                        aria-expanded="false" aria-controls="navbarCollapseSix">
                                        Contacts
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-12">
                        <div class="menu-contact-info">
                            <div class="location">
                                <h5>
                                    The Shadman Town
                                </h5>
                                <p>
                                    Shadman No 1, Shara-e-Sher Shah Shuri Road, Karachi
                                </p>
                            </div>
                            <h4>
                                shafisani458@gmail.com
                            </h4>
                            <div class="socials">
                                <a href="#" class="d-inline-block" target="_blank">
                                    <i class="ri-facebook-circle-fill"></i>
                                </a>
                                <a href="#" class="d-inline-block" target="_blank">
                                    <i class="ri-instagram-line"></i>
                                </a>
                                <a href="#" class="d-inline-block" target="_blank">
                                    <i class="ri-threads-line"></i>
                                </a>
                                <a href="#" class="d-inline-block" target="_blank">
                                    <i class="ri-twitter-x-line"></i>
                                </a>
                                <a href="#" class="d-inline-block" target="_blank">
                                    <i class="ri-youtube-fill"></i>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <button type="button" class="menu-popup-close-btn position-absolute rounded-circle text-center border-0 p-0">
        <i class="ri-close-line"></i>
    </button>
</div>

<!-- ========== YOUR EXISTING MENU POPUP HTML HERE ========== -->

<!-- ADD THIS SCRIPT AT THE END OF BODY -->
<script>
    // ========== MENU NAVIGATION LOGIC ==========

    // SELECT ALL ACCORDION BUTTONS
    document.querySelectorAll('.menu-popup-area .accordion-button').forEach((btn) => {
        // GET THE INNER <a> IF IT EXISTS
        const link = btn.querySelector('a');

        // IF LINK EXISTS (E.G. HOME BUTTON)
        if (link) {
            btn.addEventListener('click', (e) => {
                e.preventDefault(); // PREVENT DEFAULT ACCORDION BEHAVIOR
                const url = link.getAttribute('href');
                if (url && url.trim() !== '#') {
                    window.location.href = url; // REDIRECT TO PAGE
                }
            });
        }
        // IF THERE IS NO <a> TAG, YOU CAN DEFINE TARGET URL MANUALLY HERE:
        else {
            btn.addEventListener('click', () => {
                const text = btn.textContent.trim().toLowerCase();

                // ========== PAGE ROUTING LOGIC ==========
                switch (text) {
                    case 'works':
                        window.location.href = './works.php';
                        break;
                    case 'services':
                        window.location.href = './services.php';
                        break;
                    case 'about us':
                        window.location.href = './about.php';
                        break;
                    case 'blogs':
                        window.location.href = './blog.php';
                        break;
                    case 'contacts':
                        window.location.href = './contact.php';
                        break;
                    default:
                        // OPTIONAL: FALLBACK OR DO NOTHING
                        break;
                }
            });
        }
    });
</script>

<!-- End Menu Popup Area -->