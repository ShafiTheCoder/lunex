
<!-- Start Menu Popup Area -->
<div class="menu-popup-area position-fixed start-0 end-0 top-0 bottom-0">
    <div class="d-table">
        <div class="d-table-cell">
            <div class="container">
                <div class="row align-items-center">
                    <div class="col-lg-8 col-md-12">
                        <div class="meanu-popup-nav">
                            <div class="accordion" id="navbarAccordion">
                                <div class="accordion-item border-0 rounded-0 bg-transparent">
                                    <button
                                        class="accordion-button d-block w-100 shadow-none position-relative text-decoration-none bg-transparent fw-semibold collapsed"
                                        type="button" data-bs-toggle="collapse" data-bs-target="#navbarCollapseOne"
                                        aria-expanded="false" aria-controls="navbarCollapseOne">
                                        Home
                                    </button>
                                </div>
                                <div class="accordion-item border-0 rounded-0 bg-transparent">
                                    <button
                                        class="accordion-button d-block w-100 shadow-none position-relative text-decoration-none bg-transparent fw-semibold collapsed"
                                        type="button" data-bs-toggle="collapse" data-bs-target="#navbarCollapseTwo"
                                        aria-expanded="false" aria-controls="navbarCollapseTwo">
                                        Works
                                    </button>
                                </div>
                                <div class="accordion-item border-0 rounded-0 bg-transparent">
                                    <button
                                        class="accordion-button d-block w-100 shadow-none position-relative text-decoration-none bg-transparent fw-semibold collapsed"
                                        type="button" data-bs-toggle="collapse" data-bs-target="#navbarCollapseThree"
                                        aria-expanded="false" aria-controls="navbarCollapseThree">
                                        About us
                                    </button>
                                </div>
                                <div class="accordion-item border-0 rounded-0 bg-transparent">
                                    <button
                                        class="accordion-button d-block w-100 shadow-none position-relative text-decoration-none bg-transparent fw-semibold collapsed active"
                                        type="button" data-bs-toggle="collapse" data-bs-target="#navbarCollapseFour"
                                        aria-expanded="false" aria-controls="navbarCollapseFour">
                                        Pages
                                    </button>
                                </div>
                                <div class="accordion-item border-0 rounded-0 bg-transparent">
                                    <button
                                        class="accordion-button d-block w-100 shadow-none position-relative text-decoration-none bg-transparent fw-semibold collapsed"
                                        type="button" data-bs-toggle="collapse" data-bs-target="#navbarCollapseFive"
                                        aria-expanded="false" aria-controls="navbarCollapseFive">
                                        Blogs
                                    </button>
                                </div>
                                <div class="accordion-item border-0 rounded-0 bg-transparent">
                                    <button
                                        class="accordion-button d-block w-100 shadow-none position-relative text-decoration-none bg-transparent fw-semibold collapsed"
                                        type="button" data-bs-toggle="collapse" data-bs-target="#navbarCollapseSix"
                                        aria-expanded="false" aria-controls="navbarCollapseSix">
                                        Contacts
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-12">
                        <div class="menu-contact-info">
                            <div class="location">
                                <h5>
                                    The Empire State
                                </h5>
                                <p>
                                    Parker Avenue, Kingsley Road, New York
                                </p>
                                <div class="language-switcher dropdown">

                                </div>

                            </div>
                            <h4>
                                support@lunex.com
                            </h4>
                            <div class="socials">
                                <a href="#" class="d-inline-block" target="_blank">
                                    <i class="ri-facebook-circle-fill"></i>
                                </a>
                                <a href="#" class="d-inline-block" target="_blank">
                                    <i class="ri-instagram-line"></i>
                                </a>
                                <a href="#" class="d-inline-block" target="_blank">
                                    <i class="ri-threads-line"></i>
                                </a>
                                <a href="#" class="d-inline-block" target="_blank">
                                    <i class="ri-twitter-x-line"></i>
                                </a>
                                <a href="#" class="d-inline-block" target="_blank">
                                    <i class="ri-youtube-fill"></i>
                                </a>
                            </div>
                            <div class="language-widget">
                                <button id="langBtn">
                                    🌐 Select Language <span id="selectedLang">EN</span>
                                </button>
                                <ul id="langMenu" class="hidden">
                                    <li data-lang="en">English</li>
                                    <li data-lang="ur">Urdu</li>
                                    <li data-lang="fr">French</li>
                                    <li data-lang="es">Spanish</li>
                                    <li data-lang="ar">Arabic</li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <button type="button" class="menu-popup-close-btn position-absolute rounded-circle text-center border-0 p-0">
        <i class="ri-close-line"></i>
    </button>
</div>
<!-- End Menu Popup Area -->