<!-- Preloader -->
<div class="preloader-area position-fixed top-0 start-0 end-0 bottom-0 text-center">
    <div class="h-100 d-flex align-items-center justify-content-center">
        <div class="loader"></div>
    </div>
</div>
<!-- End Preloader -->