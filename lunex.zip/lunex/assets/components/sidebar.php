<!-- Sidemenu Area -->
<div class="sidemenu-area d-none d-lg-block">
    <a href="index-3.php" class="logo d-inline-block">
        <span style="font-weight:900; font-size:20px; display: block;">Softrise Techology</span>
    </a>
    <button class="navbar-toggler" type="button">
        <img src="assets/images/icons/menu.svg" alt="menu">
    </button>
    <div class="socials">
        <a href="#" class="d-block" target="_blank">
            <i class="ri-facebook-circle-fill"></i>
        </a>
        <a href="#" class="d-block" target="_blank">
            <i class="ri-instagram-line"></i>
        </a>
        <a href="#" class="d-block" target="_blank">
            <i class="ri-threads-line"></i>
        </a>
        <a href="#" class="d-block" target="_blank">
            <i class="ri-twitter-x-line"></i>
        </a>
        <a href="#" class="d-block" target="_blank">
            <i class="ri-youtube-fill"></i>
        </a>
    </div>
</div>
<!-- End Sidemenu Area -->