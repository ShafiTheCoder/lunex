<footer class="creative-agency-footer-area">
    <div class="container">
        <div class="row">
            <div class="col-lg-6 col-md-6">
                <div class="footer-left-side position-relative">
                    <h2 class="mb-0">
                        Collaborate with
                        <img src="assets/images/users/user1.jpg" class="rounded-circle" alt="user-image">
                        <span>us</span>
                    </h2>
                    <a href="contact.php" class="link-btn menu_link text-center d-inline-block rounded-circle"
                        data-cue="slideInUp">
                        <img src="assets/images/icons/white-right-top-arrow.svg" alt="right-top-arrow">
                        <span class="menu_link-text">Let's Chat</span>
                    </a>
                    <div class="newsletter-form-wrapper">
                        <span class="title d-block fw-medium">
                            Subscribe for updates
                        </span>
                        <form class="newsletter-form position-relative">
                            <input type="text" class="input-newsletter d-block w-100" placeholder="Your email here"
                                name="email" required autocomplete="off">
                            <button type="submit">
                                <i class="ri-send-plane-fill"></i>
                            </button>
                        </form>
                    </div>
                </div>
            </div>
            <div class="col-lg-6 col-md-6">
                <div class="footer-right-side">
                    <div class="socials">
                        <a href="#" class="d-inline-block" target="_blank">
                            <i class="ri-facebook-circle-fill"></i>
                        </a>
                        <a href="#" class="d-inline-block" target="_blank">
                            <i class="ri-instagram-line"></i>
                        </a>
                        <a href="#" class="d-inline-block" target="_blank">
                            <i class="ri-threads-line"></i>
                        </a>
                        <a href="#" class="d-inline-block" target="_blank">
                            <i class="ri-twitter-x-line"></i>
                        </a>
                        <a href="#" class="d-inline-block" target="_blank">
                            <i class="ri-youtube-fill"></i>
                        </a>
                    </div>
                    <div class="custom-links row">
                        <div class="col-6">
                            <h3>
                                Useful links
                            </h3>
                            <ul class="ps-0 mb-0 list-unstyled">
                                <li>
                                    <a href="index-3.php">
                                        Home
                                    </a>
                                </li>
                                <li>
                                    <a href="services.php">
                                        Services
                                    </a>
                                </li>
                                <li>
                                    <a href="about.php">
                                        About
                                    </a>
                                </li>
                                <li>
                                    <a href="blog.php">
                                        Blog
                                    </a>
                                </li>
                            </ul>
                        </div>
                        <div class="col-6">
                            <h3>
                                Useful links
                            </h3>
                            <ul class="ps-0 mb-0 list-unstyled">
                                <li>
                                    <a href="terms-conditions.php">
                                     Term & Condition
                                    </a>
                                </li>
                                <li>
                                    <a href="works.php">
                                        Works
                                    </a>
                                </li>
                                <li>
                                    <a href="contact.php">
                                        Contact
                                    </a>
                                </li>
                                <li>
                                    <a href="privacy-policy.php">
                                        privay and policy
                                    </a>
                                </li>
                            </ul>
                        </div>
                    </div>
                    <div class="location">
                        <div class="position-relative">
                            <img src="assets/images/icons/map-marker.svg" alt="map-marker-icon">
                            <h3>
                                The Shadman Town
                            </h3>
                            <span class="d-block">
                                Shadman No 1, Shara-e-Sher Shah Shuri Road, Karachi
                            </span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="copyright-area position-relative">
            <div class="go-top rounded-circle">
                <img src="assets/images/icons/up-arrow.svg" alt="up-arrow">
                <img src="assets/images/icons/white-up-arrow.svg" alt="white-up-arrow">
            </div>
        </div>
    </div>
</footer>