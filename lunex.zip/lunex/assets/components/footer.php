<!-- Start Footer Area -->
<footer class="dev-agency-footer-area py-5">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-lg-4 col-sm-6 order-1 order-lg-1">
                <div class="single-footer-widget">
                    <a href="index.php" class="logo d-inline-block">
                        <img src="assets/images/logo.svg" alt="logo" class="black-logo">
                        <img src="assets/images/white-logo.svg" class="d-none" alt="logo">
                    </a>
                    <span class="location d-block">
                        Shadman No 1, Shara-e-Sher Shah Shuri Road, Karachi
                    </span>
                    <a href="tel:+1800987-6543" class="number d-inline-block">
                        +92 324 3284 192
                    </a>
                </div>
            </div>
            <div class="col-lg-4 col-md-12 order-3 order-lg-2">
                <div class="custom-links">
                    <div class="row">
                        <div class="col-6">
                            <h3>
                                Useful links
                            </h3>
                            <ul class="ps-0 mb-0 list-unstyled">
                                <li>
                                    <a href="index-3.php">
                                        Home
                                    </a>
                                </li>
                                <li>
                                    <a href="works.php">
                                        Works
                                    </a>
                                </li>
                                <li>
                                    <a href="about.php">
                                        About
                                    </a>
                                </li>
                                <li>
                                    <a href="services.php">
                                        Services
                                    </a>
                                </li>
                            </ul>
                        </div>
                        <div class="col-6">
                            <h3>
                                Useful links
                            </h3>
                            <ul class="ps-0 mb-0 list-unstyled">
                                <li>
                                    <a href="terms-conditions.php">
                                        term & conditions
                                    </a>
                                </li>
                                <li>
                                    <a href="privacy-policy.php">
                                        privacy policy
                                    </a>
                                </li>
                                <li>
                                    <a href="blog.php">
                                        Blog
                                    </a>
                                </li>
                                <li>
                                    <a href="contact.php">
                                        Contact Us
                                    </a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-4 col-sm-6 order-2 order-lg-3">
                <div class="single-footer-widget">
                    <h3>
                        Subscribe for updates
                    </h3>
                    <form class="newsletter-form">
                        <input type="email" placeholder="Your email here"
                            class="form-control bg-transparent rounded-0 shadow-none" name="email" required
                            autocomplete="off">
                        <button type="submit">
                            Subscribe
                            <i class="ri-arrow-right-up-line"></i>
                        </button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</footer>
<!-- End Footer Area -->