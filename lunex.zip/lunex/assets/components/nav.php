<!-- Start Navbar Area -->
<div class="navbar-area style-two top-0 start-0 end-0 h-auto">
    <div class="container">
        <nav class="navbar p-0">
            <a class="navbar-brand" href="index.php">
                <img src="assets/images/logo.svg" alt="logo" class="black-logo">
                <img src="assets/images/white-logo.svg" class="d-none" alt="logo">
            </a>
            <button class="navbar-toggler" type="button">
                <span class="burger-menu">
                    <span class="top-bar"></span>
                    <span class="middle-bar"></span>
                    <span class="bottom-bar"></span>
                </span>
            </button>
            <div class="collapse navbar-collapse">
                <div class="others-option">
                    <button type="button" class="light-dark-btn d-inline-block p-0 bg-transparent border-0 lh-1"
                        id="light-dark-btn">
                        <i class="ri-sun-line"></i>
                    </button>
                </div>
            </div>
        </nav>
    </div>
</div>
<!-- End Navbar Area -->