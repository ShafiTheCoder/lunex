<!-- Footer Area -->
<footer class="footer_area">
    <div class="white_top_rectangle"></div>
    <div class="container py-5 pt-150">
        <div class="footer_content">
            <h2 class="text-white text_animation fw-bold">
                Have an Idea?
            </h2>
            <h2 class="text-white text_animation fw-bold">
                Let's Work Together!
            </h2>
            <a href="contact.php" class="btn primary_btn" data-cue="slideInUp">
                <span class="d-inline-block position-relative">
                    Get Started for Free <i class="ri-arrow-right-up-line"></i>
                </span>
            </a>
        </div>
        <div class="pt-150"></div>
        <div class="footer_inner_box" data-cue="slideInUp">
            <div class="row">
                <div class="col-lg-4">
                    <div class="footer_logo_widget">
                        <a href="index.php" class="d-inline-block">
                            <img src="assets/images/white-logo.svg" alt="logo">
                        </a>
                        <div class="newsletter_box">
                            <h4 class="fw-semibold text-white">
                                Follow the Newest Trends
                            </h4>
                            <form>
                                <input type="text" class="form-control" placeholder="Email address">
                                <button type="button">
                                    Subscribe
                                </button>
                            </form>
                        </div>
                    </div>
                </div>
                <div class="col-lg-8">
                    <div class="footer_widgets_list">
                        <div class="row">
                            <div class="col-sm-4">
                                <div class="footer_widget">
                                    <h3 class="text-white fw-semibold">
                                        Quick links
                                    </h3>
                                    <ul class="links p-0 mb-0 list-unstyled">
                                        <li>
                                            <a href="index-3.php">
                                                Home
                                            </a>
                                        </li>
                                        <li>
                                            <a href="about.php">
                                                About Us
                                            </a>
                                        </li>
                                        <li>
                                            <a href="works.php">
                                                Work
                                            </a>
                                        </li>
                                        <li>
                                            <a href="services.php">
                                                Services
                                            </a>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                            <div class="col-sm-4">
                                <div class="footer_widget">
                                    <h3 class="text-white fw-semibold">
                                        Utility Pages
                                    </h3>
                                    <ul class="links p-0 mb-0 list-unstyled">
                                        <li>
                                            <a href="privacy-policy.php">
                                                Privacy Policy
                                            </a>
                                        </li>
                                        <li>
                                            <a href="terms-conditions.php">
                                                Terms & Conditions
                                            </a>
                                        </li>
                                        <li>
                                            <a href="privacy-policy.php">
                                                Contact Us
                                            </a>
                                        </li>
                                        <li>
                                            <a href="blog.php">
                                                Blog
                                            </a>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                            <div class="col-sm-4">
                                <div class="footer_widget">
                                    <h3 class="text-white fw-semibold">
                                        Contact Info
                                    </h3>
                                    <ul class="links p-0 mb-0 list-unstyled">
                                        <li>
                                            <a href="tel:+024(453)-5432">
                                                +92 324 3284 192
                                            </a>
                                        </li>
                                        <li>
                                            <a href="contact.php">
                                                Reach Us
                                            </a>
                                        </li>
                                        <li>
                                            <a href="mailto:lunex@example.com">
                                                shafisani458@gmail.com
                                            </a>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</footer>
<!-- End Footer Area -->