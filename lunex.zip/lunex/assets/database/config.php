<?php
$host = 'localhost';       // DATABASE HOST (USUALLY 'localhost')
$user = 'root';            // DATABASE USERNAME
$pass = '';                // DATABASE PASSWORD
$dbname = 'lunexs';        // DATABASE NAME

$conn = new mysqli($host, $user, $pass, $dbname);

if ($conn->connect_error) {
    die("Database Connection Failed: " . $conn->connect_error);
}

$conn->set_charset("utf8mb4");

// ========== CONNECTION SUCCESS MESSAGE (COMMENT OUT IN PRODUCTION) ==========
# echo "Connected successfully to the lunexs database.";
?>
