<?php
// ========== INCLUDE DATABASE CONFIG ==========
include('../database/config.php');

// ========== CHECK IF REQUEST METHOD IS POST ==========
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    // ========== COLLECT FORM DATA SAFELY ==========
    $full_name = trim($_POST['full_name'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $service_type = trim($_POST['service_type'] ?? '');
    $message = trim($_POST['message'] ?? '');

    // ========== VALIDATE REQUIRED FIELDS ==========
    if (empty($full_name) || empty($email) || empty($service_type) || empty($message)) {
        echo json_encode([
            "status" => "error",
            "message" => "All fields are required."
        ]);
        exit;
    }

    // ========== PREPARE SQL STATEMENT ==========
    $stmt = $conn->prepare("INSERT INTO contact_messages (full_name, email, service_type, message) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("ssss", $full_name, $email, $service_type, $message);

    // ========== EXECUTE AND RETURN RESPONSE ==========
    if ($stmt->execute()) {
        echo json_encode([
            "status" => "success",
            "message" => "Your message has been sent successfully!"
        ]);
    } else {
        echo json_encode([
            "status" => "error",
            "message" => "Database error: " . $stmt->error
        ]);
    }

    $stmt->close();
    $conn->close();

} else {
    // ========== INVALID REQUEST METHOD ==========
    echo json_encode([
        "status" => "error",
        "message" => "Invalid request method."
    ]);
}
?>
