<!DOCTYPE html>
<html lang="zxx">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Link of CSS files -->
    <?php
    include("./assets/components/links.php")
        ?>

    <title>Lunex - Creative Agency HTML Template</title>
    <link rel="icon" type="image/png" href="assets/images/favicon.png">
</head>

<body class="bg-f8f9fd">

    <!-- Preloader -->
    <?php
    include("./assets/components/pre-loader.php")
        ?>
    <!-- End Preloader -->

    <!-- Start Navbar Area -->
    <?php
    include("./assets/components/contact-side-bar.php")
        ?>
    <!-- End Navbar Area -->

    <!-- Start Menu Popup Area -->
    <?php
    include("./assets/components/sidebar-menu.php")
        ?>
    <!-- End Menu Popup Area -->

    <!-- Start Page Banner Area -->
    <div class="page-banner-area">
        <div class="container">
            <div class="page-banner-content mx-auto text-center">
                <h1 class="mb-0 text-animation">
                    Privacy policy
                </h1>
            </div>
        </div>
    </div>
    <!-- End Page Banner Area -->

    <!-- Start Privacy Policy Area -->
    <div class="privacy-policy-area ptb-150">
        <div class="container">
            <div class="privacy-policy-content">
                <p>
                    Effective date: Mar 23, 2025
                </p>
                <p>
                    At <strong>Lunex</strong>, we respect your privacy and are committed to protecting your personal
                    data. This privacy policy outlines how we collect, use, and safeguard your information when you
                    visit our website, interact with our services, or make use of our products.
                </p>
                <h4>
                    Information we collect
                </h4>
                <p>
                    We collect personal information that you provide to us when you interact with our website, including
                    but not limited to:
                </p>
                <ul>
                    <li>
                        <strong>Personal Identifiable Information (PII)</strong> such as your name, email address, phone
                        number, etc.
                    </li>
                    <li>
                        <strong>Non-personally identifiable information</strong> such as browser type, operating system,
                        pages visited on our site, and time spent on each page.
                    </li>
                </ul>
                <h4>
                    How we use your information
                </h4>
                <p>
                    The information we collect may be used in the following ways:
                </p>
                <ul>
                    <li>
                        To provide and improve our services
                    </li>
                    <li>
                        To personalize your experience on our website
                    </li>
                    <li>
                        To process your transactions or respond to customer service requests
                    </li>
                    <li>
                        To send you updates, promotional offers, or newsletters (if you’ve opted in)
                    </li>
                </ul>
                <h4>
                    Cookies and tracking technologies
                </h4>
                <p>
                    We use cookies to enhance your user experience and to collect information about your usage patterns
                    on our site. You can disable <strong>cookies</strong> in your browser settings, but please note that
                    this may limit some functionality of the website.
                </p>
                <h4>
                    How we protect your information
                </h4>
                <p>
                    We implement a variety of security measures to maintain the safety of your personal information when
                    you place an order or enter, submit, or access your personal information. We use encryption
                    technologies, secure servers, and other security measures to safeguard your data.
                </p>
                <h4>
                    Sharing your information
                </h4>
                <p>
                    We do not sell, trade, or transfer your personal information to third parties without your consent,
                    except in the following cases:
                </p>
                <ul>
                    <li>
                        <strong>Service Providers:</strong> We may share your information with trusted third-party
                        vendors who assist us in operating our website, conducting our business, or providing services
                        to you.
                    </li>
                    <li>
                        <strong>Legal Compliance:</strong> We may disclose your information to comply with legal
                        obligations or protect our rights.
                    </li>
                </ul>
                <h4>
                    Third-party links
                </h4>
                <p>
                    Occasionally, our website may contain links to <u>third-party <i>websites</i></u>. These third-party
                    sites have separate and independent privacy policies. We are not responsible for the content or
                    practices of these linked sites.
                </p>
                <h4>
                    Your rights
                </h4>
                <p>
                    You have the right to:
                </p>
                <ul>
                    <li>
                        Access, update, or delete your personal information.
                    </li>
                    <li>
                        Opt-out of marketing communications by following the unsubscribe instructions in any email you
                        receive from us.
                    </li>
                    <li>
                        Withdraw your consent to the collection of your information at any time.
                    </li>
                </ul>
                <h4>
                    Children’s privacy
                </h4>
                <p>
                    Our website is not intended for <a href="index.php">children</a> under the age of 13. We do not
                    knowingly collect personal information from children. If we become aware that we have inadvertently
                    collected personal data from a child, we will take steps to delete that information.
                </p>
                <h4>
                    Changes to this privacy policy
                </h4>
                <p>
                    We may update this privacy policy periodically. Any changes will be posted on this page, and we will
                    update the effective date accordingly.
                </p>
                <h4>
                    Contact us
                </h4>
                <p>
                    If you have any questions regarding this privacy policy, or if you wish to <a href="#"
                        target="_blank">exercise</a> your rights, please contact us at:
                </p>
                <h4>
                    Lunex
                </h4>
                <ul>
                    <li>
                        Email: <a href="mailto:support@lunex.com">support@lunex.com</a>
                    </li>
                    <li>
                        Phone: <a href="tel:+1(555)123-4567">+1 (555) 123-4567</a>
                    </li>
                    <li>
                        Address: Parker Avenue, Kingsley Road, New York
                    </li>
                </ul>
            </div>
        </div>
    </div>
    <!-- End Privacy Policy Area -->

    <!-- Start Footer Area -->
    <?php
    include("./assets/components/footer-two.php")
        ?>
    <!-- End Footer Area -->

    <!-- Link of JS files -->
    <?php
    include("./assets/components/script.php")
        ?>
    <!-- ========== GOOGLE TRANSLATE CONTAINER (HIDDEN) ========== -->
    <div id="google_translate_element" style="display:none;"></div>

    <script>
        // ========== GOOGLE TRANSLATE INITIALIZE ==========
        function loadGoogleTranslate() {
            new google.translate.TranslateElement({
                pageLanguage: 'en',
                includedLanguages: 'en,ur,fr,es,ar'
            }, 'google_translate_element');
        }
    </script>
    <script src="https://translate.google.com/translate_a/element.js?cb=loadGoogleTranslate"></script>

    <script>
        // ========== APPLY SAVED LANGUAGE ON EVERY PAGE ==========
        document.addEventListener("DOMContentLoaded", function () {
            const savedLang = localStorage.getItem("selectedLanguage");

            if (savedLang) {
                const checkExist = setInterval(() => {
                    const combo = document.querySelector(".goog-te-combo");
                    if (combo) {
                        combo.value = savedLang;
                        combo.dispatchEvent(new Event("change"));
                        clearInterval(checkExist);
                    }
                }, 400);
            }
        });
    </script>

</body>

</html>