<!DOCTYPE html>
<html lang="zxx">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Link of CSS files -->
    <?php
    include("./assets/components/links.php")
        ?>

    <title>Lunex - Creative Agency HTML Template</title>
    <link rel="icon" type="image/png" href="assets/images/favicon.png">
</head>

<body class="bg-f8f9fd">

    <!-- Preloader -->
    <?php
    include("./assets/components/pre-loader.php")
        ?>
    <!-- End Preloader -->

    <!-- Start Navbar Area -->
    <?php
    include("./assets/components/contact-side-bar.php")
        ?>
    <!-- End Navbar Area -->

    <!-- Start Navbar Area -->
    <?php
    include("./assets/components/contact-side-bar.php")
        ?>
    <!-- End Navbar Area -->

    <!-- Start Menu Popup Area -->
    <?php
    include("./assets/components/sidebar-menu.php")
        ?>
    <!-- End Menu Popup Area -->

    <!-- Start About Page Banner Area -->
    <div class="about-page-banner-area">
        <div class="container">
            <div class="row">
                <div class="col-lg-5 col-md-12">
                    <div class="content">
                        <span class="sub-title d-block">
                            About us
                        </span>
                        <h1 class="mb-0 text-animation">
                            Discover who we <span>truly are</span>
                        </h1>
                    </div>
                </div>
                <div class="col-lg-7 col-md-12">
                    <div class="image" data-cue="slideInUp">
                        <img src="assets/images/abouts/about2.jpg" alt="about-image">
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- End About Page Banner Area -->

    <!-- Start About Area -->
    <div class="about-area">
        <div class="container" data-cues="slideInUp">
            <div class="about-funfacts">
                <div class="row align-items-center">
                    <div class="col-lg-6 col-md-12">
                        <p>
                            Explore our journey, values, and expertise that define who we are. From innovation to
                            excellence, we are committed to delivering impactful solutions that drive success.
                        </p>
                    </div>
                    <div class="col-lg-6 col-md-12">
                        <div class="funfacts d-flex align-items-center justify-content-between">
                            <div class="item">
                                <div class="number lh-1">
                                    199+
                                </div>
                                <span class="d-block">
                                    Proud clients
                                </span>
                            </div>
                            <div class="item">
                                <div class="number lh-1">
                                    212+
                                </div>
                                <span class="d-block">
                                    Completed initiatives
                                </span>
                            </div>
                            <div class="item">
                                <div class="number lh-1">
                                    20+
                                </div>
                                <span class="d-block">
                                    Trophies
                                </span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="about-video-box text-center position-relative">
                <img src="assets/images/abouts/about3.jpg" alt="about-image">
                <a href="https://www.youtube.com/watch?v=HKk4oLIzhhM"
                    class="video-btn popup-youtube d-flex align-items-center justify-content-center rounded-circle">
                    <i class="ri-play-fill"></i>
                </a>
            </div>
            <div class="about-features-list">
                <ul class="ps-0 mb-0 list-unstyled">
                    <li class="position-relative d-inline-block fw-semibold">
                        Creativity
                    </li>
                    <li class="position-relative d-inline-block fw-semibold">
                        Partnership
                    </li>
                </ul>
            </div>
        </div>
    </div>
    <!-- End About Area -->

    <!-- Start Our Mission Area -->
    <div class="our-mission-area ptb-150">
        <div class="container">
            <div class="creative-agency-section-title">
                <div class="row align-items-center">
                    <div class="col-lg-8 col-md-6">
                        <div class="left-side">
                            <h2 class="text-animation">
                                Our purpose <span class="text-primary">& journey</span>
                            </h2>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6">
                        <div class="right-side style-two">
                            <p>
                                We are dedicated to driving innovation and helping brands thrive in the digital world
                                with tailored solutions that make an impact.
                            </p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="our-mission-accordion accordion" id="missionAccordion" data-cues="slideInUp">
                <div class="accordion-item">
                    <button class="accordion-button" type="button" data-bs-toggle="collapse"
                        data-bs-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                        Empowerment
                    </button>
                    <div id="collapseOne" class="accordion-collapse collapse show" data-bs-parent="#missionAccordion">
                        <div class="accordion-body">
                            <p>
                                Our mission is to empower brands with innovative strategies, creative solutions, and
                                cutting-edge technologies that drive sustainable growth and success. We are committed to
                                helping brands thrive in an ever-evolving digital landscape, providing them with the
                                tools they need to stay ahead.
                            </p>
                        </div>
                    </div>
                </div>
                <div class="accordion-item">
                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
                        data-bs-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
                        Transformation
                    </button>
                    <div id="collapseTwo" class="accordion-collapse collapse" data-bs-parent="#missionAccordion">
                        <div class="accordion-body">
                            <p>
                                Driven by our passion for creativity and technology, we are focused on transforming
                                ideas into remarkable digital experiences. We craft solutions that not only make an
                                impact but also inspire change, helping businesses stand out and connect with their
                                audiences in meaningful ways.
                            </p>
                        </div>
                    </div>
                </div>
                <div class="accordion-item">
                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
                        data-bs-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
                        Navigation
                    </button>
                    <div id="collapseThree" class="accordion-collapse collapse" data-bs-parent="#missionAccordion">
                        <div class="accordion-body">
                            <p>
                                We are dedicated to helping businesses successfully navigate the complex digital world.
                                By combining innovative thinking with effective strategy, we provide comprehensive
                                solutions that foster growth and guide businesses through their digital journey,
                                ensuring long-term success in an ever-changing marketplace.
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- End Our Mission Area -->

    <!-- Start How We Work Area -->
    <div class="how-we-work-area bg-black ptb-150 position-relative z-1">
        <div class="container">
            <div class="creative-agency-section-title text-white">
                <div class="row">
                    <div class="col-lg-8 col-md-6">
                        <div class="left-side">
                            <h2 class="text-animation">
                                Our way of <span>working</span>
                            </h2>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6">
                        <div class="right-side style-two">
                            <p>
                                At <strong>NsaTheme</strong>, we believe in a collaborative approach that aligns with
                                your vision. We start by understanding your needs, objectives, and challenges, allowing
                                us to craft custom strategies tailored to your business.
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="container-fluid" data-cue="slideInUp">
            <div class="swiper howWeWorkSwiper">
                <div class="swiper-wrapper">
                    <div class="swiper-slide">
                        <div class="how-we-work-box">
                            <h3>
                                Discovery phase
                            </h3>
                            <p>
                                In this initial phase, we dive deep into understanding your business, goals, and target
                                audience. We conduct research and analyze your industry landscape to gather valuable
                                insights. This helps us tailor our approach to create a clear roadmap that aligns with
                                your objectives.
                            </p>
                        </div>
                    </div>
                    <div class="swiper-slide">
                        <div class="how-we-work-box">
                            <h3>
                                Strategy creation
                            </h3>
                            <p>
                                Based on the insights gathered in the discovery phase, we craft a comprehensive strategy
                                that outlines key tactics and goals. This strategy is designed to drive growth, improve
                                brand presence, and ensure long-term success. We prioritize innovation, creativity, and
                                practicality.
                            </p>
                        </div>
                    </div>
                    <div class="swiper-slide">
                        <div class="how-we-work-box">
                            <h3>
                                Collaborative process
                            </h3>
                            <p>
                                Collaboration is at the heart of our process. Throughout the project, we maintain open
                                channels of communication to ensure we're aligned with your expectations. Regular
                                feedback helps us fine-tune designs, functionality, and other aspects, ensuring the end
                                product meets your needs.
                            </p>
                        </div>
                    </div>
                    <div class="swiper-slide">
                        <div class="how-we-work-box">
                            <h3>
                                Design development
                            </h3>
                            <p>
                                Once the strategy is finalized, we move forward with designing and developing the
                                solution. Our design team creates engaging visuals, while our developers ensure the
                                functionality is seamless and user-friendly. We use the latest technologies to build
                                robust, scalable, and secure solutions.
                            </p>
                        </div>
                    </div>
                    <div class="swiper-slide">
                        <div class="how-we-work-box">
                            <h3>
                                Quality assurance
                            </h3>
                            <p>
                                Before launching, we rigorously test the project to identify and fix any issues. Our
                                quality assurance team runs multiple tests to ensure that the product is not only
                                bug-free but also optimized for performance. This process ensures the highest quality
                                outcome.
                            </p>
                        </div>
                    </div>
                    <div class="swiper-slide">
                        <div class="how-we-work-box">
                            <h3>
                                Ongoing support
                            </h3>
                            <p>
                                Once everything is set, we launch your product into the digital world. Our job doesn’t
                                end there—we provide ongoing support and maintenance to ensure the project continues to
                                perform effectively. We also monitor results and suggest improvements for continuous
                                growth and success.
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="shape6">
            <img src="assets/images/shapes/shape6.svg" alt="shape6">
        </div>
    </div>
    <!-- End How We Work Area -->

    <!-- Start Awards Area -->
    <div class="awards-area ptb-150">
        <div class="container">
            <div class="creative-agency-section-title">
                <div class="left-side">
                    <h2 class="text-animation">
                        Our wins & <span class="text-primary">honors</span>
                    </h2>
                </div>
            </div>
            <div class="awards-recognitions-list" data-cues="slideInUp">
                <div class="item position-relative">
                    <div class="row align-items-center">
                        <div class="col-lg-4 col-md-4">
                            <span class="title d-block">
                                Creative Spark
                            </span>
                        </div>
                        <div class="col-lg-3 col-md-3">
                            <span class="title two d-block">
                                Winner
                            </span>
                        </div>
                        <div class="col-lg-3 col-md-3">
                            <span class="title three d-block">
                                PixelCrafters
                            </span>
                        </div>
                        <div class="col-lg-2 col-md-2">
                            <a href="#" target="_blank"
                                class="link-btn d-flex align-items-center justify-content-md-end">
                                <i class="ri-arrow-right-up-line"></i>
                                View
                            </a>
                        </div>
                    </div>
                    <div class="image">
                        <img src="assets/images/recognitions/recognition1.jpg" alt="recognitions-image">
                    </div>
                </div>
                <div class="item position-relative">
                    <div class="row align-items-center">
                        <div class="col-lg-4 col-md-4">
                            <span class="title d-block">
                                Tech Visionary
                            </span>
                        </div>
                        <div class="col-lg-3 col-md-3">
                            <span class="title two d-block">
                                Winner
                            </span>
                        </div>
                        <div class="col-lg-3 col-md-3">
                            <span class="title three d-block">
                                VisionaryTech
                            </span>
                        </div>
                        <div class="col-lg-2 col-md-2">
                            <a href="#" target="_blank"
                                class="link-btn d-flex align-items-center justify-content-md-end">
                                <i class="ri-arrow-right-up-line"></i>
                                View
                            </a>
                        </div>
                    </div>
                    <div class="image">
                        <img src="assets/images/recognitions/recognition2.jpg" alt="recognitions-image">
                    </div>
                </div>
                <div class="item position-relative">
                    <div class="row align-items-center">
                        <div class="col-lg-4 col-md-4">
                            <span class="title d-block">
                                Design Mastery
                            </span>
                        </div>
                        <div class="col-lg-3 col-md-3">
                            <span class="title two d-block">
                                Nominee
                            </span>
                        </div>
                        <div class="col-lg-3 col-md-3">
                            <span class="title three d-block">
                                DesignMinds
                            </span>
                        </div>
                        <div class="col-lg-2 col-md-2">
                            <a href="#" target="_blank"
                                class="link-btn d-flex align-items-center justify-content-md-end">
                                <i class="ri-arrow-right-up-line"></i>
                                View
                            </a>
                        </div>
                    </div>
                    <div class="image">
                        <img src="assets/images/recognitions/recognition3.jpg" alt="recognitions-image">
                    </div>
                </div>
                <div class="item position-relative">
                    <div class="row align-items-center">
                        <div class="col-lg-4 col-md-4">
                            <span class="title d-block">
                                Innovation Leader
                            </span>
                        </div>
                        <div class="col-lg-3 col-md-3">
                            <span class="title two d-block">
                                Nominee
                            </span>
                        </div>
                        <div class="col-lg-3 col-md-3">
                            <span class="title three d-block">
                                NextGen Solutions
                            </span>
                        </div>
                        <div class="col-lg-2 col-md-2">
                            <a href="#" target="_blank"
                                class="link-btn d-flex align-items-center justify-content-md-end">
                                <i class="ri-arrow-right-up-line"></i>
                                View
                            </a>
                        </div>
                    </div>
                    <div class="image">
                        <img src="assets/images/recognitions/recognition4.jpg" alt="recognitions-image">
                    </div>
                </div>
                <div class="item position-relative">
                    <div class="row align-items-center">
                        <div class="col-lg-4 col-md-4">
                            <span class="title d-block">
                                Brand Power
                            </span>
                        </div>
                        <div class="col-lg-3 col-md-3">
                            <span class="title two d-block">
                                Winner
                            </span>
                        </div>
                        <div class="col-lg-3 col-md-3">
                            <span class="title three d-block">
                                BrandFlow
                            </span>
                        </div>
                        <div class="col-lg-2 col-md-2">
                            <a href="#" target="_blank"
                                class="link-btn d-flex align-items-center justify-content-md-end">
                                <i class="ri-arrow-right-up-line"></i>
                                View
                            </a>
                        </div>
                    </div>
                    <div class="image">
                        <img src="assets/images/recognitions/recognition5.jpg" alt="recognitions-image">
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- End Awards Area -->

    <!-- Start Team Area -->
    <div class="team-area">
        <div class="container">
            <div class="creative-agency-section-title">
                <div class="left-side">
                    <h2 class="text-animation">
                        The team that <span class="text-primary">drives us</span>
                    </h2>
                </div>
            </div>
            <div class="teamSwiper position-relative" data-cue="slideInUp">
                <div class="swiper">
                    <div class="swiper-wrapper">
                        <div class="swiper-slide">
                            <div class="single-team-member">
                                <img src="assets/images/teams/team1.jpg" alt="team-image">
                                <div class="content d-flex justify-content-between align-items-end">
                                    <div class="title">
                                        <h3>
                                            David Wilson
                                        </h3>
                                        <span class="d-block">
                                            Content Strategist
                                        </span>
                                    </div>
                                    <div class="socials">
                                        <a href="#" target="_blank" class="d-inline-block">
                                            <i class="ri-instagram-line"></i>
                                        </a>
                                        <a href="#" target="_blank" class="d-inline-block">
                                            <i class="ri-facebook-circle-fill"></i>
                                        </a>
                                        <a href="#" target="_blank" class="d-inline-block">
                                            <i class="ri-threads-line"></i>
                                        </a>
                                        <a href="#" target="_blank" class="d-inline-block">
                                            <i class="ri-twitter-x-line"></i>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="swiper-slide">
                            <div class="single-team-member">
                                <img src="assets/images/teams/team2.jpg" alt="team-image">
                                <div class="content d-flex justify-content-between align-items-end">
                                    <div class="title">
                                        <h3>
                                            Sophia Martinez
                                        </h3>
                                        <span class="d-block">
                                            Marketing Specialist
                                        </span>
                                    </div>
                                    <div class="socials">
                                        <a href="#" target="_blank" class="d-inline-block">
                                            <i class="ri-instagram-line"></i>
                                        </a>
                                        <a href="#" target="_blank" class="d-inline-block">
                                            <i class="ri-facebook-circle-fill"></i>
                                        </a>
                                        <a href="#" target="_blank" class="d-inline-block">
                                            <i class="ri-threads-line"></i>
                                        </a>
                                        <a href="#" target="_blank" class="d-inline-block">
                                            <i class="ri-twitter-x-line"></i>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="swiper-slide">
                            <div class="single-team-member">
                                <img src="assets/images/teams/team3.jpg" alt="team-image">
                                <div class="content d-flex justify-content-between align-items-end">
                                    <div class="title">
                                        <h3>
                                            James Taylor
                                        </h3>
                                        <span class="d-block">
                                            Software Engineer
                                        </span>
                                    </div>
                                    <div class="socials">
                                        <a href="#" target="_blank" class="d-inline-block">
                                            <i class="ri-instagram-line"></i>
                                        </a>
                                        <a href="#" target="_blank" class="d-inline-block">
                                            <i class="ri-facebook-circle-fill"></i>
                                        </a>
                                        <a href="#" target="_blank" class="d-inline-block">
                                            <i class="ri-threads-line"></i>
                                        </a>
                                        <a href="#" target="_blank" class="d-inline-block">
                                            <i class="ri-twitter-x-line"></i>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="swiper-slide">
                            <div class="single-team-member">
                                <img src="assets/images/teams/team4.jpg" alt="team-image">
                                <div class="content d-flex justify-content-between align-items-end">
                                    <div class="title">
                                        <h3>
                                            Olivia White
                                        </h3>
                                        <span class="d-block">
                                            Graphic Designer
                                        </span>
                                    </div>
                                    <div class="socials">
                                        <a href="#" target="_blank" class="d-inline-block">
                                            <i class="ri-instagram-line"></i>
                                        </a>
                                        <a href="#" target="_blank" class="d-inline-block">
                                            <i class="ri-facebook-circle-fill"></i>
                                        </a>
                                        <a href="#" target="_blank" class="d-inline-block">
                                            <i class="ri-threads-line"></i>
                                        </a>
                                        <a href="#" target="_blank" class="d-inline-block">
                                            <i class="ri-twitter-x-line"></i>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="btn-box d-flex align-items-center">
                    <div class="swiper-button-prev">
                        <i class="ri-arrow-left-line"></i>
                    </div>
                    <div class="swiper-button-next">
                        <i class="ri-arrow-right-line"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- End Team Area -->

    <!-- Start Trusted Clients Area -->
    <div class="trusted-clients-area ptb-150">
        <div class="container">
            <div class="creative-agency-section-title">
                <div class="row align-items-center">
                    <div class="col-lg-8 col-md-6">
                        <div class="left-side">
                            <h2 class="text-animation">
                                Clients we <span class="text-primary">value</span>
                            </h2>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6">
                        <div class="right-side style-two">
                            <p>
                                At NsaTheme, we are proud to work with a diverse range of clients who trust us to bring
                                their digital visions to life.
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="container-fluid" data-cue="slideInUp">
            <div class="swiper trustedClientsSwiperTwo">
                <div class="swiper-wrapper">
                    <div class="swiper-slide">
                        <div class="item">
                            <img src="assets/images/partners/partner1.svg" alt="client-image">
                        </div>
                    </div>
                    <div class="swiper-slide">
                        <div class="item two">
                            <img src="assets/images/partners/partner2.svg" alt="client-image">
                        </div>
                    </div>
                    <div class="swiper-slide">
                        <div class="item">
                            <img src="assets/images/partners/partner3.svg" alt="client-image">
                        </div>
                    </div>
                    <div class="swiper-slide">
                        <div class="item two">
                            <img src="assets/images/partners/partner4.svg" alt="client-image">
                        </div>
                    </div>
                    <div class="swiper-slide">
                        <div class="item">
                            <img src="assets/images/partners/partner5.svg" alt="client-image">
                        </div>
                    </div>
                    <div class="swiper-slide">
                        <div class="item two">
                            <img src="assets/images/partners/partner6.svg" alt="client-image">
                        </div>
                    </div>
                    <div class="swiper-slide">
                        <div class="item">
                            <img src="assets/images/partners/partner1.svg" alt="client-image">
                        </div>
                    </div>
                    <div class="swiper-slide">
                        <div class="item two">
                            <img src="assets/images/partners/partner2.svg" alt="client-image">
                        </div>
                    </div>
                    <div class="swiper-slide">
                        <div class="item">
                            <img src="assets/images/partners/partner3.svg" alt="client-image">
                        </div>
                    </div>
                    <div class="swiper-slide">
                        <div class="item two">
                            <img src="assets/images/partners/partner4.svg" alt="client-image">
                        </div>
                    </div>
                    <div class="swiper-slide">
                        <div class="item">
                            <img src="assets/images/partners/partner5.svg" alt="client-image">
                        </div>
                    </div>
                    <div class="swiper-slide">
                        <div class="item two">
                            <img src="assets/images/partners/partner6.svg" alt="client-image">
                        </div>
                    </div>
                    <div class="swiper-slide">
                        <div class="item">
                            <img src="assets/images/partners/partner1.svg" alt="client-image">
                        </div>
                    </div>
                    <div class="swiper-slide">
                        <div class="item two">
                            <img src="assets/images/partners/partner2.svg" alt="client-image">
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- End Trusted Clients Area -->

    <!-- Start Footer Area -->
    <?php
    include("./assets/components/footer-two.php")
        ?>
    <!-- Link of JS files -->
    <?php
    include("./assets/components/script.php")
        ?>
    <!-- ========== GOOGLE TRANSLATE CONTAINER (HIDDEN) ========== -->
    <div id="google_translate_element" style="display:none;"></div>

    <script>
        // ========== GOOGLE TRANSLATE INITIALIZE ==========
        function loadGoogleTranslate() {
            new google.translate.TranslateElement({
                pageLanguage: 'en',
                includedLanguages: 'en,ur,fr,es,ar'
            }, 'google_translate_element');
        }
    </script>
    <script src="https://translate.google.com/translate_a/element.js?cb=loadGoogleTranslate"></script>

    <script>
        // ========== APPLY SAVED LANGUAGE ON EVERY PAGE ==========
        document.addEventListener("DOMContentLoaded", function () {
            const savedLang = localStorage.getItem("selectedLanguage");

            if (savedLang) {
                const checkExist = setInterval(() => {
                    const combo = document.querySelector(".goog-te-combo");
                    if (combo) {
                        combo.value = savedLang;
                        combo.dispatchEvent(new Event("change"));
                        clearInterval(checkExist);
                    }
                }, 400);
            }
        });
    </script>


</body>

</html>