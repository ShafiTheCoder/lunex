<!DOCTYPE html>
<html lang="zxx">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Link of CSS files -->
    <?php
    include("./assets/components/links.php")
        ?>

    <title>Lunex - Creative Agency HTML Template</title>
    <link rel="icon" type="image/png" href="assets/images/favicon.png">
</head>

<body class="bg-f8f9fd">

    <!-- Preloader -->
    <?php
    include("./assets/components/pre-loader.php")
        ?>
    <!-- End Preloader -->

    <!-- Sidemenu Area -->
    <?php
    include("./assets/components/sidebar.php")
        ?>
    <!-- End Sidemenu Area -->

    <!-- Start Navbar Area -->
    <?php
    include("./assets/components/nav.php")
        ?>
    <!-- End Navbar Area -->

    <!-- Start Menu Popup Area -->
    <?php
    include("./assets/components/menu.php")
        ?>
    <!-- End Menu Popup Area -->

    <!-- ========== LANGUAGE SELECTOR CONTAINER ========== -->
    <div class="language-widget">
        <button id="langBtn">
            🌐 Select Language <span id="selectedLang">EN</span>
        </button>
        <ul id="langMenu" class="hidden">
            <li data-lang="en">English</li>
            <li data-lang="ur">Urdu</li>
            <li data-lang="fr">French</li>
            <li data-lang="es">Spanish</li>
            <li data-lang="ar">Arabic</li>
        </ul>
    </div>

    <!-- ========== GOOGLE TRANSLATE SCRIPT ========== -->
    <div id="google_translate_element" style="display:none;"></div>
    <script>
        function loadGoogleTranslate() {
            new google.translate.TranslateElement({
                pageLanguage: 'en',
                includedLanguages: 'en,ur,fr,es,ar'
            }, 'google_translate_element');
        }
    </script>
    <script src="https://translate.google.com/translate_a/element.js?cb=loadGoogleTranslate"></script>

    <!-- ========== CUSTOM TRANSLATE SCRIPT ========== -->
    <script>
        document.addEventListener("DOMContentLoaded", function () {
            const btn = document.getElementById("langBtn");
            const menu = document.getElementById("langMenu");
            const selectedLangText = document.getElementById("selectedLang");

            // TOGGLE MENU
            btn.addEventListener("click", () => menu.classList.toggle("hidden"));

            // CLOSE MENU WHEN CLICK OUTSIDE
            document.addEventListener("click", (e) => {
                if (!e.target.closest(".language-widget")) {
                    menu.classList.add("hidden");
                }
            });

            // HANDLE LANGUAGE CHANGE
            menu.querySelectorAll("li").forEach(item => {
                item.addEventListener("click", () => {
                    const lang = item.dataset.lang;
                    const combo = document.querySelector(".goog-te-combo");
                    if (combo) {
                        combo.value = lang;
                        combo.dispatchEvent(new Event("change"));
                        selectedLangText.textContent = lang.toUpperCase();
                        localStorage.setItem("selectedLanguage", lang);
                    }
                    menu.classList.add("hidden");
                });
            });

            // AUTO APPLY SAVED LANGUAGE
            const savedLang = localStorage.getItem("selectedLanguage");
            if (savedLang) {
                const interval = setInterval(() => {
                    const combo = document.querySelector(".goog-te-combo");
                    if (combo) {
                        combo.value = savedLang;
                        combo.dispatchEvent(new Event("change"));
                        selectedLangText.textContent = savedLang.toUpperCase();
                        clearInterval(interval);
                    }
                }, 500);
            }
        });
    </script>

    <style>
        /* ========== LANGUAGE SELECTOR STYLING ========== */
        .language-widget {
            position: fixed;
            bottom: 30px;
            right: 30px;
            z-index: 9999;
            font-family: "Poppins", sans-serif;
        }

        /* ========== BUTTON STYLE ========== */
        .language-widget button {
            color: blue;
            background-color: transparent;
            border: none;
            padding: 10px 18px;
            border-radius: 30px;
            cursor: pointer;
            font-size: 14px;
            font-weight: 500;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.2);
            transition: all 0.3s ease;
        }

        .language-widget button:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 16px rgba(0, 0, 0, 0.25);
        }

        /* ========== DROPDOWN MENU (SLIDE UP) ========== */
        .language-widget ul {
            position: absolute;
            right: 0;
            bottom: 45px;
            /* 👈 CHANGE: appear above the button */
            background: #fff;
            border-radius: 10px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
            list-style: none;
            margin: 0;
            padding: 8px 0;
            overflow: hidden;
            width: 160px;
            animation: slideUp 0.3s ease;
        }

        .language-widget ul.hidden {
            display: none;
        }

        .language-widget li {
            padding: 10px 15px;
            cursor: pointer;
            color: #333;
            font-weight: 500;
            transition: background 0.2s;
        }

        .language-widget li:hover {
            background: #f5f5ff;
            color: #6b5bff;
        }

        /* ========== ANIMATION FOR SLIDE-UP ========== */
        @keyframes slideUp {
            from {
                opacity: 0;
                transform: translateY(10px);
            }

            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        /* HIDE DEFAULT GOOGLE UI */
        .goog-logo-link,
        .goog-te-gadget span {
            display: none !important;
        }

        .goog-te-gadget {
            color: transparent !important;
        }
    </style>

    <!-- Start Dev Agency Banner Area -->
    <div class="dev-agency-banner-area position-relative z-1">
        <div class="container">
            <div class="dev-agency-banner-content">
                <div class="h1 fw-normal">
                    <div class="one">
                        <span class="d-block">
                            Create
                        </span>
                    </div>
                    <div class="two position-relative">
                        <span class="d-block">
                            transform
                        </span>
                    </div>
                    <div class="three">
                        <span class="d-block">
                            & code
                        </span>
                    </div>
                </div>
                <p data-cue="slideInUp">
                    We design, develop, and code innovative digital solutions to bring ideas to life.
                </p>
            </div>
            <div class="dev-agency-banner-text" data-cue="slideInUp">
                <a href="contact.php" class="link-btn menu_link text-center d-inline-block rounded-circle">
                    <img src="assets/images/icons/white-right-top-arrow.svg" alt="right-top-arrow">
                    <span class="menu_link-text">
                        Let's Chat
                    </span>
                </a>
                <p>
                    We create and code impactful digital products from concept to execution.
                </p>
            </div>
            <div class="shape4">
                <img src="assets/images/banners/banner3.jpg" alt="banner3">
            </div>
        </div>
        <div class="border1">
            <img src="assets/images/shapes/border1.svg" alt="border1">
        </div>
        <div class="border2">
            <img src="assets/images/shapes/border2.svg" alt="border2">
        </div>
    </div>
    <!-- End Dev Agency Banner Area -->

    <!-- Start About Area -->
    <div class="about-area">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-lg-7">
                    <div class="about-content text-animation">
                        <img src="assets/images/abouts/element.svg" class="rotateme" alt="element-image">
                        <p class="fw-medium">
                            We combine creativity and technology to transform ideas into impactful digital solutions.
                            Driven by innovation and a <img src="assets/images/abouts/star.png" alt="star"> commitment
                            to client satisfaction, we strive to exceed
                            expectations and deliver exceptional results.
                        </p>
                    </div>
                    <div class="about-btn" data-cue="slideInUp">
                        <a href="contact.php"
                            class="link-btn menu_link d-inline-block text-center position-relative rounded-circle">
                            <img src="assets/images/icons/right-top-arrow.svg" alt="right-top-arrow">
                            <img src="assets/images/icons/white-right-top-arrow.svg" alt="white-right-top-arrow">
                            <span class="menu_link-text">
                                Let's Chat
                            </span>
                        </a>
                    </div>
                </div>
                <div class="col-lg-5">
                    <div class="about-image" data-cue="zoomIn">
                        <img src="assets/images/abouts/about1.jpg" alt="about-image">
                        <div class="d-flex align-items-center">
                            <span class="sub-title d-block">
                                We rank in the top
                            </span>
                            <div class="number">
                                5%
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- End About Area -->

    <!-- Start Services Area -->
    <div class="services-area ptb-150">
        <div class="container">
            <div class="dev-agency-section-title">
                <div class="row align-items-end">
                    <div class="col-lg-7 col-md-12">
                        <div class="left-side">
                            <h2 class="text-animation">
                                Discover our <span>offerings</span>
                            </h2>
                        </div>
                    </div>
                    <div class="col-lg-5 col-md-12">
                        <div class="right-side">
                            <a href="services.php" class="default-btn style-two mt-0">
                                View Services
                                <i class="ri-arrow-right-up-line"></i>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="dev-services-list" data-cues="slideInUp">
                <div class="item position-relative">
                    <div class="icon">
                        <img src="assets/images/icons/web-dev.svg" alt="icon">
                    </div>
                    <h3>
                        <a href="service-single.php">
                            Brand strategy
                        </a>
                    </h3>
                    <p>
                        We help define your brand’s identity and create a roadmap for consistent growth, positioning,
                        and market presence.
                    </p>
                    <a href="service-single.php" class="link-btn d-inline-block">
                        <i class="ri-arrow-right-line"></i>
                    </a>
                </div>
                <div class="item position-relative">
                    <div class="icon">
                        <img src="assets/images/icons/app-dev.svg" alt="icon">
                    </div>
                    <h3>
                        <a href="service-single.php">
                            Creative design
                        </a>
                    </h3>
                    <p>
                        From logos to websites, our creative design solutions bring your brand to life with visually
                        stunning and user-centric designs.
                    </p>
                    <a href="service-single.php" class="link-btn d-inline-block">
                        <i class="ri-arrow-right-line"></i>
                    </a>
                </div>
                <div class="item position-relative">
                    <div class="icon">
                        <img src="assets/images/icons/ecommerce-solutions.svg" alt="icon">
                    </div>
                    <h3>
                        <a href="service-single.php">
                            Digital marketing
                        </a>
                    </h3>
                    <p>
                        We craft tailored digital marketing strategies that engage your audience, boost conversions, &
                        build brand loyalty across multiple platforms.
                    </p>
                    <a href="service-single.php" class="link-btn d-inline-block">
                        <i class="ri-arrow-right-line"></i>
                    </a>
                </div>
                <div class="item position-relative">
                    <div class="icon">
                        <img src="assets/images/icons/maintenance-support.svg" alt="icon">
                    </div>
                    <h3>
                        <a href="service-single.php">
                            Web development
                        </a>
                    </h3>
                    <p>
                        Our expert web development team creates high-performance websites & applications that enhance
                        experience & functionality.
                    </p>
                    <a href="service-single.php" class="link-btn d-inline-block">
                        <i class="ri-arrow-right-line"></i>
                    </a>
                </div>
            </div>
        </div>
    </div>
    <!-- End Services Area -->

    <!-- Start Projects Area -->
    <div class="projects-area pb-150">
        <div class="container">
            <div class="dev-agency-section-title">
                <div class="row align-items-end">
                    <div class="col-lg-7 col-md-12">
                        <div class="left-side">
                            <h2 class="text-animation">
                                Our works <span>gallery</span>
                            </h2>
                        </div>
                    </div>
                    <div class="col-lg-5 col-md-12">
                        <div class="right-side">
                            <p>
                                A glimpse into our creativity and expertise—explore the projects that define our
                                commitment to innovation and excellence.
                            </p>
                            <a href="works.php" class="default-btn style-two">
                                All Works
                                <i class="ri-arrow-right-up-line"></i>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="projects-list" data-cue="slideInUp">
                <div class="project-item active">
                    <div class="title">
                        <div class="number">
                            01
                        </div>
                        <span>
                            Brand elevation strategy
                        </span>
                    </div>
                    <div class="details">
                        <div class="row align-items-center">
                            <div class="col-xl-7 col-lg-6 col-md-7">
                                <div class="image text-center">
                                    <img src="assets/images/projects/project1.jpg" alt="project-image">
                                </div>
                            </div>
                            <div class="col-xl-5 col-lg-6 col-md-5">
                                <div class="content">
                                    <div class="number">
                                        01
                                    </div>
                                    <h3>
                                        <a href="work-single.php">
                                            Brand elevation strategy
                                        </a>
                                    </h3>
                                    <p>
                                        A comprehensive rebranding project aimed at boosting brand identity and
                                        increasing market presence through strategic design and messaging.
                                    </p>
                                    <a href="work-single.php"
                                        class="link-btn text-center d-inline-block rounded-circle position-relative">
                                        <i class="ri-arrow-right-line"></i>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="project-item">
                    <div class="title">
                        <div class="number">
                            02
                        </div>
                        <span>
                            High-impact ad campaign
                        </span>
                    </div>
                    <div class="details">
                        <div class="row align-items-center">
                            <div class="col-xl-7 col-lg-6 col-md-7">
                                <div class="image text-center">
                                    <img src="assets/images/projects/project2.jpg" alt="project-image">
                                </div>
                            </div>
                            <div class="col-xl-5 col-lg-6 col-md-5">
                                <div class="content">
                                    <div class="number">
                                        02
                                    </div>
                                    <h3>
                                        <a href="work-single.php">
                                            High-impact ad campaign
                                        </a>
                                    </h3>
                                    <p>
                                        A targeted advertising campaign designed to maximize brand visibility and drive
                                        customer engagement through creative and impactful visuals.
                                    </p>
                                    <a href="work-single.php"
                                        class="link-btn text-center d-inline-block rounded-circle position-relative">
                                        <i class="ri-arrow-right-line"></i>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="project-item">
                    <div class="title">
                        <div class="number">
                            03
                        </div>
                        <span>
                            Engaging social media revamp
                        </span>
                    </div>
                    <div class="details">
                        <div class="row align-items-center">
                            <div class="col-xl-7 col-lg-6 col-md-7">
                                <div class="image text-center">
                                    <img src="assets/images/projects/project3.jpg" alt="project-image">
                                </div>
                            </div>
                            <div class="col-xl-5 col-lg-6 col-md-5">
                                <div class="content">
                                    <div class="number">
                                        03
                                    </div>
                                    <h3>
                                        <a href="work-single.php">
                                            Engaging social media revamp
                                        </a>
                                    </h3>
                                    <p>
                                        A transformation of social media presence, focusing on creative content and
                                        effective strategies to increase engagement and build brand loyalty.
                                    </p>
                                    <a href="work-single.php"
                                        class="link-btn text-center d-inline-block rounded-circle position-relative">
                                        <i class="ri-arrow-right-line"></i>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="project-item">
                    <div class="title">
                        <div class="number">
                            04
                        </div>
                        <span>
                            Next-level web development
                        </span>
                    </div>
                    <div class="details">
                        <div class="row align-items-center">
                            <div class="col-xl-7 col-lg-6 col-md-7">
                                <div class="image text-center">
                                    <img src="assets/images/projects/project4.jpg" alt="project-image">
                                </div>
                            </div>
                            <div class="col-xl-5 col-lg-6 col-md-5">
                                <div class="content">
                                    <div class="number">
                                        04
                                    </div>
                                    <h3>
                                        <a href="work-single.php">
                                            Next-level web development
                                        </a>
                                    </h3>
                                    <p>
                                        Building modern, responsive websites with cutting-edge technology and a focus on
                                        functionality and design to ensure optimal user experience.
                                    </p>
                                    <a href="work-single.php"
                                        class="link-btn text-center d-inline-block rounded-circle position-relative">
                                        <i class="ri-arrow-right-line"></i>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- End Projects Area -->

    <!-- Start Feedback Area -->
    <div class="feedback-area pb-150">
        <div class="container">
            <div class="dev-agency-section-title">
                <div class="row align-items-end">
                    <div class="col-xl-7 col-lg-9 col-md-12">
                        <div class="left-side">
                            <span class="sub-title d-block">
                                Valued clients
                            </span>
                            <h2 class="text-animation">
                                Respected and valued clients
                            </h2>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="container-fluid" data-cue="slideInUp">
            <div class="feedbackSwiperStyleTwo position-relative">
                <div class="swiper">
                    <div class="swiper-wrapper">
                        <div class="swiper-slide">
                            <div class="feedback-box position-relative z-1">
                                <img src="assets/images/users/user7.jpg" class="user rounded-circle" alt="user-image">
                                <p>
                                    The team’s creative strategy transformed our brand's presence. With a fresh and
                                    engaging design, we gained a new identity that resonates deeply with our audience,
                                    positioning us as a standout in a competitive market. Our brand recognition has
                                    skyrocketed
                                    since the launch.
                                </p>
                                <h3>
                                    Sarah Thompson
                                </h3>
                                <span class="d-block">
                                    CEO, InnovateTech Solutions
                                </span>
                                <div class="shape3">
                                    <img src="assets/images/shapes/shape3.svg" alt="shape3">
                                </div>
                            </div>
                        </div>
                        <div class="swiper-slide">
                            <div class="feedback-box position-relative z-1">
                                <img src="assets/images/users/user8.jpg" class="user rounded-circle" alt="user-image">
                                <p>
                                    From initial concepts to final execution, the team delivered beyond our
                                    expectations. The brand overhaul not only strengthened our online presence but also
                                    resulted in a significant increase in customer engagement and sales. Their creative
                                    approach was
                                    exactly what we needed.
                                </p>
                                <h3>
                                    John Harrison
                                </h3>
                                <span class="d-block">
                                    Marketing Director, Elite Enterprises
                                </span>
                                <div class="shape3">
                                    <img src="assets/images/shapes/shape3.svg" alt="shape3">
                                </div>
                            </div>
                        </div>
                        <div class="swiper-slide">
                            <div class="feedback-box position-relative z-1">
                                <img src="assets/images/users/user9.jpg" class="user rounded-circle" alt="user-image">
                                <p>
                                    The agency’s creative approach was exactly what our business needed. Their work made
                                    us stand out in an already crowded market. We’ve seen an impressive increase in
                                    website traffic and customer inquiries, all thanks to their fresh ideas and
                                    strategic
                                    thinking.
                                </p>
                                <h3>
                                    Emily Roberts
                                </h3>
                                <span class="d-block">
                                    Founder, Urban Innovators
                                </span>
                                <div class="shape3">
                                    <img src="assets/images/shapes/shape3.svg" alt="shape3">
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="btn-box d-flex align-items-center justify-content-between">
                    <div class="swiper-pagination"></div>
                    <div class="swiper-navigation">
                        <div class="swiper-button-prev">
                            <i class="ri-arrow-left-line"></i>
                        </div>
                        <div class="swiper-button-next">
                            <i class="ri-arrow-right-line"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- End Feedback Area -->

    <!-- Start Partners Area -->
    <div class="partners-area pb-150">
        <div class="container-fluid">
            <div class="partnersSwiperOne swiper">
                <div class="swiper-wrapper">
                    <div class="swiper-slide">
                        <div class="partner-item">
                            <img src="assets/images/partners/partner1.svg" alt="partner-image">
                        </div>
                    </div>
                    <div class="swiper-slide">
                        <div class="partner-item">
                            <img src="assets/images/partners/partner2.svg" alt="partner-image">
                        </div>
                    </div>
                    <div class="swiper-slide">
                        <div class="partner-item">
                            <img src="assets/images/partners/partner3.svg" alt="partner-image">
                        </div>
                    </div>
                    <div class="swiper-slide">
                        <div class="partner-item">
                            <img src="assets/images/partners/partner4.svg" alt="partner-image">
                        </div>
                    </div>
                    <div class="swiper-slide">
                        <div class="partner-item">
                            <img src="assets/images/partners/partner5.svg" alt="partner-image">
                        </div>
                    </div>
                    <div class="swiper-slide">
                        <div class="partner-item">
                            <img src="assets/images/partners/partner6.svg" alt="partner-image">
                        </div>
                    </div>
                    <div class="swiper-slide">
                        <div class="partner-item">
                            <img src="assets/images/partners/partner1.svg" alt="partner-image">
                        </div>
                    </div>
                    <div class="swiper-slide">
                        <div class="partner-item">
                            <img src="assets/images/partners/partner2.svg" alt="partner-image">
                        </div>
                    </div>
                </div>
            </div>
            <div class="partnersSwiperTwo swiper" dir="rtl">
                <div class="swiper-wrapper">
                    <div class="swiper-slide">
                        <div class="partner-item">
                            <img src="assets/images/partners/partner1.svg" alt="partner-image">
                        </div>
                    </div>
                    <div class="swiper-slide">
                        <div class="partner-item">
                            <img src="assets/images/partners/partner2.svg" alt="partner-image">
                        </div>
                    </div>
                    <div class="swiper-slide">
                        <div class="partner-item">
                            <img src="assets/images/partners/partner3.svg" alt="partner-image">
                        </div>
                    </div>
                    <div class="swiper-slide">
                        <div class="partner-item">
                            <img src="assets/images/partners/partner4.svg" alt="partner-image">
                        </div>
                    </div>
                    <div class="swiper-slide">
                        <div class="partner-item">
                            <img src="assets/images/partners/partner5.svg" alt="partner-image">
                        </div>
                    </div>
                    <div class="swiper-slide">
                        <div class="partner-item">
                            <img src="assets/images/partners/partner6.svg" alt="partner-image">
                        </div>
                    </div>
                    <div class="swiper-slide">
                        <div class="partner-item">
                            <img src="assets/images/partners/partner1.svg" alt="partner-image">
                        </div>
                    </div>
                    <div class="swiper-slide">
                        <div class="partner-item">
                            <img src="assets/images/partners/partner2.svg" alt="partner-image">
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- End Partners Area -->

    <!-- Start Blog Area -->
    <div class="blog-area pb-150">
        <div class="container">
            <div class="dev-agency-section-title">
                <div class="row align-items-end">
                    <div class="col-lg-7 col-md-12">
                        <div class="left-side">
                            <h2 class="text-animation">
                                Our recent <span>posts</span>
                            </h2>
                        </div>
                    </div>
                    <div class="col-lg-5 col-md-12">
                        <div class="right-side">
                            <a href="blog.php" class="default-btn style-two mt-0">
                                View Posts
                                <i class="ri-arrow-right-up-line"></i>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="dev-blogs-list" data-cues="slideInUp">
                <div class="blog-item position-relative">
                    <div class="content position-relative">
                        <ul class="meta ps-0 list-unstyled">
                            <li class="d-inline-block position-relative">
                                Jan 2025
                            </li>
                            <li class="d-inline-block position-relative">
                                10 PM
                            </li>
                        </ul>
                        <h3>
                            <a href="blog-single.php">
                                The power of storytelling in branding
                            </a>
                        </h3>
                        <p>
                            Storytelling in branding creates emotional connections, builds trust, and fosters customer
                            loyalty through compelling narratives that engage audiences.
                        </p>
                    </div>
                    <a href="blog-single.php" class="image d-block">
                        <img src="assets/images/blogs/blog7.jpg" alt="blog-image">
                    </a>
                </div>
                <div class="blog-item position-relative">
                    <div class="content position-relative">
                        <ul class="meta ps-0 list-unstyled">
                            <li class="d-inline-block position-relative">
                                Feb 2025
                            </li>
                            <li class="d-inline-block position-relative">
                                11 AM
                            </li>
                        </ul>
                        <h3>
                            <a href="blog-single.php">
                                Creative campaigns that inspire action
                            </a>
                        </h3>
                        <p>
                            Crafting innovative campaigns that drive engagement and inspire meaningful action, turning
                            ideas into impactful results.
                        </p>
                    </div>
                    <a href="blog-single.php" class="image d-block">
                        <img src="assets/images/blogs/blog8.jpg" alt="blog-image">
                    </a>
                </div>
                <div class="blog-item position-relative">
                    <div class="content position-relative">
                        <ul class="meta ps-0 list-unstyled">
                            <li class="d-inline-block position-relative">
                                Mar 2025
                            </li>
                            <li class="d-inline-block position-relative">
                                12 PM
                            </li>
                        </ul>
                        <h3>
                            <a href="blog-single.php">
                                The importance of ux/ui in building customer trust
                            </a>
                        </h3>
                        <p>
                            Good UX/UI design enhances user experience, making websites and apps intuitive and easy to
                            navigate, which builds trust, boosts customer satisfaction, and encourages long-term
                            engagement.
                        </p>
                    </div>
                    <a href="blog-single.php" class="image d-block">
                        <img src="assets/images/blogs/blog9.jpg" alt="blog-image">
                    </a>
                </div>
            </div>
        </div>
    </div>
    <!-- End Blog Area -->

    <!-- Start Transform Area -->
    <div class="transform-area">
        <div class="container">
            <div class="transform-content">
                <h2 class="text-animation">
                    Bring your vision to life with simple, effective solutions
                </h2>
                <p>
                    Discover our collection of diverse projects that showcase our expertise and commitment. From elegant
                    designs to advanced functionalities, our work highlights creativity and precision.
                </p>
            </div>
            <div class="transform-boxes mx-auto position-relative" data-cues="slideInUp">
                <img src="assets/images/shapes/border.svg" class="border-image" alt="border-image">
                <div class="box1">
                    <h3 class="fw-normal">
                        Design perfection
                    </h3>
                    <p>
                        Browse through our collection of varied projects that showcase our commitment and expertise.
                    </p>
                </div>
                <div class="box2"></div>
                <div class="box3"></div>
            </div>
        </div>
    </div>
    <!-- End Transform Area -->

    <!-- Start FAQ Area -->
    <div class="faq-area ptb-150">
        <div class="container">
            <div class="dev-agency-section-title">
                <div class="row align-items-end">
                    <div class="col-lg-7 col-md-12">
                        <div class="left-side">
                            <span class="sub-title d-block">
                                Need help?
                            </span>
                            <h2 class="text-animation">
                                Questions we get asked
                            </h2>
                        </div>
                    </div>
                    <div class="col-lg-5 col-md-12">
                        <div class="right-side">
                            <a href="faq.php" class="default-btn style-two">
                                View FAQ
                                <i class="ri-arrow-right-up-line"></i>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="dev-agency-faq-accordion accordion" id="devAgencyFaqAccordion" data-cues="slideInUp">
                <div class="accordion-item">
                    <button class="accordion-button" type="button" data-bs-toggle="collapse"
                        data-bs-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                        <span class="number d-inline-block rounded-circle text-center">
                            01
                        </span>
                        What services do you offer as a creative agency?
                    </button>
                    <div id="collapseOne" class="accordion-collapse collapse show"
                        data-bs-parent="#devAgencyFaqAccordion">
                        <div class="accordion-body">
                            <p>
                                We offer a wide range of services, including branding, graphic design, web development,
                                digital marketing, social media strategy, content creation, UX/UI design, and
                                advertising campaigns. Our team tailors each solution to fit the unique needs of your
                                business.
                            </p>
                        </div>
                    </div>
                </div>
                <div class="accordion-item">
                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
                        data-bs-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
                        <span class="number d-inline-block rounded-circle text-center">
                            02
                        </span>
                        How can a creative agency help my business grow?
                    </button>
                    <div id="collapseTwo" class="accordion-collapse collapse" data-bs-parent="#devAgencyFaqAccordion">
                        <div class="accordion-body">
                            <p>
                                A creative agency can help your business by crafting a strong, unique brand identity,
                                improving your online presence, engaging your target audience, and driving measurable
                                results through innovative marketing strategies. We focus on both creative and
                                strategic solutions to ensure long-term growth.
                            </p>
                        </div>
                    </div>
                </div>
                <div class="accordion-item">
                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
                        data-bs-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
                        <span class="number d-inline-block rounded-circle text-center">
                            03
                        </span>
                        How long does it take to complete a project?
                    </button>
                    <div id="collapseThree" class="accordion-collapse collapse" data-bs-parent="#devAgencyFaqAccordion">
                        <div class="accordion-body">
                            <p>
                                The duration of a project depends on its scope and complexity. A simple logo design
                                might take a couple of weeks, while a full-scale website redesign could take several
                                months. We work closely with you to provide a realistic timeline and keep you informed
                                throughout the process.
                            </p>
                        </div>
                    </div>
                </div>
                <div class="accordion-item">
                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
                        data-bs-target="#collapseFour" aria-expanded="false" aria-controls="collapseFour">
                        <span class="number d-inline-block rounded-circle text-center">
                            04
                        </span>
                        What makes your agency different from others?
                    </button>
                    <div id="collapseFour" class="accordion-collapse collapse" data-bs-parent="#devAgencyFaqAccordion">
                        <div class="accordion-body">
                            <p>
                                Our team combines creativity with strategy, ensuring that every project not only looks
                                great but also drives business results. We focus on building long-term partnerships with
                                our clients, offering personalized solutions, and staying ahead of industry
                                trends to ensure your brand stands out.
                            </p>
                        </div>
                    </div>
                </div>
                <div class="accordion-item">
                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
                        data-bs-target="#collapseFive" aria-expanded="false" aria-controls="collapseFive">
                        <span class="number d-inline-block rounded-circle text-center">
                            05
                        </span>
                        How do you determine the cost of a project?
                    </button>
                    <div id="collapseFive" class="accordion-collapse collapse" data-bs-parent="#devAgencyFaqAccordion">
                        <div class="accordion-body">
                            <p>
                                The cost of a project depends on factors like the complexity of the work, the resources
                                required, and the timeline. We provide detailed quotes after understanding your goals
                                and project requirements. We ensure transparency and work with you to create
                                a budget that fits your needs.
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- End FAQ Area -->

    <!-- Start Let's Talk Area -->
    <div class="lets-talk-area pb-150">
        <div class="container">
            <div class="lets-talk-content text-center">
                <h2 class="text-animation d-flex align-items-center justify-content-center">
                    <span>Let's</span> do this!
                </h2>
                <a href="contact.php"
                    class="link-btn menu_link d-inline-block text-center position-relative rounded-circle">
                    <img src="assets/images/icons/right-top-arrow.svg" alt="right-top-arrow">
                    <img src="assets/images/icons/white-right-top-arrow.svg" alt="white-right-top-arrow">
                    <span class="menu_link-text">
                        Let's Chat
                    </span>
                </a>
            </div>
        </div>
    </div>
    <!-- End Let's Talk Area -->

    <!-- Start Footer Area -->
    <?php
    include("./assets/components/footer.php")
        ?>
    <!-- End Footer Area -->

    <!-- Back to Top -->
    <?php
    include("./assets/components/back-to-top.php")
        ?>
    <!-- End Back to Top -->

    <!-- Link of JS files -->
    <?php
    include("./assets/components/script.php")
        ?>
</body>

</html>