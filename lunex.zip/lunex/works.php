<!DOCTYPE html>
<html lang="zxx">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Link of CSS files -->
    <?php
    include("./assets/components/links.php")
        ?>

    <title>Lunex - Creative Agency HTML Template</title>
    <link rel="icon" type="image/png" href="assets/images/favicon.png">
</head>

<body class="bg-f8f9fd">

    <!-- Preloader -->
    <?php
    include("./assets/components/pre-loader.php")
        ?>
    <!-- End Preloader -->

    <!-- Start Navbar Area -->
    <?php
    include("./assets/components/contact-side-bar.php")
        ?>
    <!-- End Navbar Area -->

    <!-- Start Menu Popup Area -->
    <?php
    include("./assets/components/sidebar-menu.php")
        ?>
    <!-- End Menu Popup Area -->

    <!-- Start Works Page Banner Area -->
    <div class="works-page-banner-area">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-lg-7 col-md-7">
                    <div class="left-side">
                        <span class="sub-title d-block">
                            Our works
                        </span>
                        <h1 class="mb-0 text-animation">
                            Our recent <span>creations</span>
                        </h1>
                    </div>
                </div>
                <div class="col-lg-5 col-md-5">
                    <div class="right-side">
                        <p>
                            Discover our latest creations, where innovation and design excellence come together to
                            deliver impactful solutions and drive success.
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- End Works Page Banner Area -->

    <!-- Start Works Area -->
    <div class="works-area pb-150">
        <div class="container" data-cue="slideInUp">
            <div class="works-shorting-menu">
                <button class="filter" data-filter="all">
                    All
                </button>
                <button class="filter" data-filter=".brand-identity">
                    Brand identity
                </button>
                <button class="filter" data-filter=".saas-solutions">
                    SaaS solutions
                </button>
                <button class="filter" data-filter=".web-design">
                    Web design
                </button>
                <button class="filter" data-filter=".digital-marketing">
                    Digital strategy
                </button>
            </div>
            <div class="works-list works-shorting">
                <div class="item mix web-design">
                    <div class="row align-items-center">
                        <div class="col-lg-3 col-md-12">
                            <div class="title position-relative">
                                <div class="number text-center rounded-circle">
                                    01
                                </div>
                                <h3 class="mb-0">
                                    <a href="work-single.php">
                                        Brand identity & web design
                                    </a>
                                </h3>
                            </div>
                        </div>
                        <div class="col-lg-6 col-md-12">
                            <div class="image position-relative">
                                <img src="assets/images/works/work1.jpg" alt="work-image">
                                <a href="work-single.php" class="link-btn text-center d-inline-block rounded-circle">
                                    <img src="assets/images/icons/primary-right-top-arrow.svg" alt="right-top-arrow">
                                    Read More
                                </a>
                            </div>
                        </div>
                        <div class="col-lg-3 col-md-12">
                            <div class="content">
                                <p>
                                    We craft unique brand identities and design visually striking websites that
                                    perfectly represent your brand.
                                </p>
                                <ul class="categories ps-0 mb-0 list-unstyled">
                                    <li class="d-inline-block">
                                        <a href="work-single.php" class="d-block">
                                            Branding
                                        </a>
                                    </li>
                                    <li class="d-inline-block">
                                        <a href="work-single.php" class="d-block">
                                            Web Design
                                        </a>
                                    </li>
                                    <li class="d-inline-block">
                                        <a href="work-single.php" class="d-block">
                                            UX/UI
                                        </a>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="item mix brand-identity digital-marketing">
                    <div class="row align-items-center">
                        <div class="col-lg-3 col-md-12">
                            <div class="title position-relative">
                                <div class="number text-center rounded-circle">
                                    02
                                </div>
                                <h3 class="mb-0">
                                    <a href="work-single.php">
                                        SaaS web development
                                    </a>
                                </h3>
                            </div>
                        </div>
                        <div class="col-lg-6 col-md-12">
                            <div class="image position-relative">
                                <img src="assets/images/works/work2.jpg" alt="work-image">
                                <a href="work-single.php" class="link-btn text-center d-inline-block rounded-circle">
                                    <img src="assets/images/icons/primary-right-top-arrow.svg" alt="right-top-arrow">
                                    Read More
                                </a>
                            </div>
                        </div>
                        <div class="col-lg-3 col-md-12">
                            <div class="content">
                                <p>
                                    We specialize in developing scalable and high-performance websites for SaaS
                                    businesses.
                                </p>
                                <ul class="categories ps-0 mb-0 list-unstyled">
                                    <li class="d-inline-block">
                                        <a href="work-single.php" class="d-block">
                                            SaaS
                                        </a>
                                    </li>
                                    <li class="d-inline-block">
                                        <a href="work-single.php" class="d-block">
                                            Web
                                        </a>
                                    </li>
                                    <li class="d-inline-block">
                                        <a href="work-single.php" class="d-block">
                                            Development
                                        </a>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="item mix saas-solutions web-design">
                    <div class="row align-items-center">
                        <div class="col-lg-3 col-md-12">
                            <div class="title position-relative">
                                <div class="number text-center rounded-circle">
                                    03
                                </div>
                                <h3 class="mb-0">
                                    <a href="work-single.php">
                                        Marketing web design
                                    </a>
                                </h3>
                            </div>
                        </div>
                        <div class="col-lg-6 col-md-12">
                            <div class="image position-relative">
                                <img src="assets/images/works/work3.jpg" alt="work-image">
                                <a href="work-single.php" class="link-btn text-center d-inline-block rounded-circle">
                                    <img src="assets/images/icons/primary-right-top-arrow.svg" alt="right-top-arrow">
                                    Read More
                                </a>
                            </div>
                        </div>
                        <div class="col-lg-3 col-md-12">
                            <div class="content">
                                <p>
                                    We create impactful and visually engaging websites tailored for marketing agencies.
                                </p>
                                <ul class="categories ps-0 mb-0 list-unstyled">
                                    <li class="d-inline-block">
                                        <a href="work-single.php" class="d-block">
                                            Marketing
                                        </a>
                                    </li>
                                    <li class="d-inline-block">
                                        <a href="work-single.php" class="d-block">
                                            Web
                                        </a>
                                    </li>
                                    <li class="d-inline-block">
                                        <a href="work-single.php" class="d-block">
                                            Solutions
                                        </a>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="item mix brand-identity digital-marketing">
                    <div class="row align-items-center">
                        <div class="col-lg-3 col-md-12">
                            <div class="title position-relative">
                                <div class="number text-center rounded-circle">
                                    04
                                </div>
                                <h3 class="mb-0">
                                    <a href="work-single.php">
                                        Agency web development
                                    </a>
                                </h3>
                            </div>
                        </div>
                        <div class="col-lg-6 col-md-12">
                            <div class="image position-relative">
                                <img src="assets/images/works/work4.jpg" alt="work-image">
                                <a href="work-single.php" class="link-btn text-center d-inline-block rounded-circle">
                                    <img src="assets/images/icons/primary-right-top-arrow.svg" alt="right-top-arrow">
                                    Read More
                                </a>
                            </div>
                        </div>
                        <div class="col-lg-3 col-md-12">
                            <div class="content">
                                <p>
                                    We build dynamic and responsive websites for digital agencies, focusing on
                                    creativity and functionality.
                                </p>
                                <ul class="categories ps-0 mb-0 list-unstyled">
                                    <li class="d-inline-block">
                                        <a href="work-single.php" class="d-block">
                                            Digital
                                        </a>
                                    </li>
                                    <li class="d-inline-block">
                                        <a href="work-single.php" class="d-block">
                                            Innovation
                                        </a>
                                    </li>
                                    <li class="d-inline-block">
                                        <a href="work-single.php" class="d-block">
                                            Design
                                        </a>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="more-project-btn text-center">
                <a href="works.php" class="d-flex align-items-center justify-content-center">
                    <i class="ri-arrow-down-line"></i>
                    More Works
                </a>
            </div>
        </div>
    </div>
    <!-- End Works Area -->

    <!-- Start Footer Area -->
    <?php
    include("./assets/components/footer-two.php")
        ?>
    <!-- End Footer Area -->

    <!-- Link of JS files -->
    <?php
    include("./assets/components/script.php")
        ?>

    <!-- ========== GOOGLE TRANSLATE CONTAINER (HIDDEN) ========== -->
    <div id="google_translate_element" style="display:none;"></div>

    <script>
        // ========== GOOGLE TRANSLATE INITIALIZE ==========
        function loadGoogleTranslate() {
            new google.translate.TranslateElement({
                pageLanguage: 'en',
                includedLanguages: 'en,ur,fr,es,ar'
            }, 'google_translate_element');
        }
    </script>
    <script src="https://translate.google.com/translate_a/element.js?cb=loadGoogleTranslate"></script>

    <script>
        // ========== APPLY SAVED LANGUAGE ON EVERY PAGE ==========
        document.addEventListener("DOMContentLoaded", function () {
            const savedLang = localStorage.getItem("selectedLanguage");

            if (savedLang) {
                const checkExist = setInterval(() => {
                    const combo = document.querySelector(".goog-te-combo");
                    if (combo) {
                        combo.value = savedLang;
                        combo.dispatchEvent(new Event("change"));
                        clearInterval(checkExist);
                    }
                }, 400);
            }
        });
    </script>

</body>

</html>