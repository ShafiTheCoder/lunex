<!DOCTYPE html>
<html lang="zxx">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Link of CSS files -->
    <?php
    include("./assets/components/links.php")
        ?>

    <title>Lunex - Creative Agency HTML Template</title>
    <link rel="icon" type="image/png" href="assets/images/favicon.png">
</head>

<body class="bg-f8f9fd">

    <!-- Preloader -->
    <?php
    include("./assets/components/pre-loader.php")
        ?>
    <!-- End Preloader -->

    <!-- Start Navbar Area -->
    <?php
    include("./assets/components/contact-side-bar.php")
        ?>
    <!-- End Navbar Area -->

    <!-- Start Menu Popup Area -->
    <?php
    include("./assets/components/sidebar-menu.php")
        ?>
    <!-- End Menu Popup Area -->


    <!-- Start Page Banner Area -->
    <div class="page-banner-area">
        <div class="container">
            <div class="page-banner-content mx-auto text-center">
                <h1 class="mb-0 text-animation">
                    Terms & conditions
                </h1>
            </div>
        </div>
    </div>
    <!-- End Page Banner Area -->

    <!-- Start Terms & Conditions Area -->
    <div class="terms-conditions-area ptb-150">
        <div class="container">
            <div class="terms-conditions-content">
                <p>
                    Effective date: Mar 23, 2025
                </p>
                <p>
                    These terms & conditions (“terms”) govern your use of the <strong>Lunex</strong> website and
                    services. By accessing or using the services provided by <strong>Lunex</strong>, you agree to comply
                    with and be bound by these terms. If you do not agree with any of the terms, please do not use our
                    services.
                </p>
                <h4>
                    Use of website
                </h4>
                <p>
                    By accessing and using the <strong>Lunex</strong> website, you agree to comply with all applicable
                    laws and regulations. You must not use the site in a way that could damage, disable, overburden, or
                    impair any part of the website, nor interfere with any other user’s enjoyment of the website.
                </p>
                <h4>
                    Eligibility
                </h4>
                <p>
                    To use our services, you must be at least 18 years of age or have parental consent if you are under
                    the age of 18. By using our services, you affirm that you meet the age requirement and are fully
                    capable of entering into these terms.
                </p>
                <h4>
                    Intellectual property
                </h4>
                <p>
                    All content available on the <strong>Lunex</strong> website, including text, graphics, logos,
                    images, videos, and other materials, are the property of <strong>Lunex</strong> or its licensors and
                    are protected by copyright and intellectual property laws. You may not use, copy, reproduce,
                    distribute, or modify any part of the website’s content without prior written permission.
                </p>
                <h4>
                    Account creation
                </h4>
                <p>
                    To use certain features of our services, you may be required to create an account. You are
                    responsible for <u>maintaining the <i>confidentiality</i></u> of your account information, including
                    your password, and for all activities that occur under your account. Please notify us immediately if
                    you believe your account has been compromised.
                </p>
                <h4>
                    Payments and subscriptions
                </h4>
                <p>
                    If you make a purchase or subscribe to our services, you agree to provide accurate and complete
                    payment information. Payments for subscription plans or services are non-refundable except as
                    required by law. All prices are subject to change, and you will be notified in advance of any
                    changes to the cost of our services.
                </p>
                <h4>
                    Prohibited activities
                </h4>
                <p>
                    You are prohibited from using the <strong>Lunex</strong> website or services for any unlawful,
                    harmful, fraudulent, or malicious activity. You may not:
                </p>
                <ul>
                    <li>
                        Engage in spamming, phishing, or other malicious activities.
                    </li>
                    <li>
                        Distribute viruses, malware, or harmful code.
                    </li>
                    <li>
                        Attempt to gain unauthorized access to any part of our website or related systems.
                    </li>
                    <li>
                        Engage in any activity that violates any applicable laws or regulations.
                    </li>
                </ul>
                <h4>
                    Privacy
                </h4>
                <p>
                    Your privacy is important to us. Please review our <a href="privacy-policy.php">privacy policy</a>
                    to understand how we collect, use, and protect your personal information.
                </p>
                <h4>
                    Termination
                </h4>
                <p>
                    We reserve the right to suspend or terminate your access to our website and services at any time,
                    without notice, for any violation of these Terms. If your account is terminated, your right to
                    access our website and services will be immediately revoked.
                </p>
                <h4>
                    Disclaimers and limitation of liability
                </h4>
                <p>
                    The <strong>Lunex</strong> website and services are provided "as is" without any warranties of any
                    kind, either express or implied. <strong>Lunex</strong> does not guarantee that the website will be
                    error-free or uninterrupted. We are not liable for any damages arising from your use or inability to
                    use our services, including any loss of data, profits, or business opportunities.
                </p>
                <h4>
                    Indemnification
                </h4>
                <p>
                    You agree to indemnify and hold harmless <strong>Lunex</strong>, its officers, employees, agents,
                    and affiliates from any claims, damages, or losses arising from your use of our services or any
                    violation of these Terms.
                </p>
                <h4>
                    Governing law
                </h4>
                <p>
                    These Terms are governed by and construed in accordance with the laws of the State of New York,
                    United States, without regard to its conflict of law principles. Any legal action or proceeding
                    related to these Terms must be brought in the appropriate courts located in New York.
                </p>
                <h4>
                    Changes to terms & conditions
                </h4>
                <p>
                    We reserve the right to modify or update these Terms at any time. Any changes will be posted on this
                    page, and the updated version will be effective as of the date it is posted. Please review these
                    Terms periodically to stay informed of any changes.
                </p>
                <h4>
                    Contact information
                </h4>
                <p>
                    If you have any questions about these Terms & Conditions, please contact us at:
                </p>
                <h4>
                    Lunex
                </h4>
                <ul>
                    <li>
                        Email: <a href="mailto:support@lunex.com">support@lunex.com</a>
                    </li>
                    <li>
                        Phone: <a href="tel:+1(555)123-4567">+1 (555) 123-4567</a>
                    </li>
                    <li>
                        Address: Parker Avenue, Kingsley Road, New York
                    </li>
                </ul>
            </div>
        </div>
    </div>
    <!-- End Terms & Conditions Area -->

    <!-- Start Footer Area -->
    <?php
    include("./assets/components/footer-two.php")
        ?>
    <!-- End Footer Area -->

    <!-- Link of JS files -->
    <?php
    include("./assets/components/script.php")
        ?>

    <!-- ========== GOOGLE TRANSLATE CONTAINER (HIDDEN) ========== -->
    <div id="google_translate_element" style="display:none;"></div>

    <script>
        // ========== GOOGLE TRANSLATE INITIALIZE ==========
        function loadGoogleTranslate() {
            new google.translate.TranslateElement({
                pageLanguage: 'en',
                includedLanguages: 'en,ur,fr,es,ar'
            }, 'google_translate_element');
        }
    </script>
    <script src="https://translate.google.com/translate_a/element.js?cb=loadGoogleTranslate"></script>

    <script>
        // ========== APPLY SAVED LANGUAGE ON EVERY PAGE ==========
        document.addEventListener("DOMContentLoaded", function () {
            const savedLang = localStorage.getItem("selectedLanguage");

            if (savedLang) {
                const checkExist = setInterval(() => {
                    const combo = document.querySelector(".goog-te-combo");
                    if (combo) {
                        combo.value = savedLang;
                        combo.dispatchEvent(new Event("change"));
                        clearInterval(checkExist);
                    }
                }, 400);
            }
        });
    </script>


</body>

</html>