<!DOCTYPE html>
<html lang="zxx">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Link of CSS files -->
    <?php
    include("./assets/components/links.php")
        ?>

    <title>Lunex - Creative Agency HTML Template</title>
    <link rel="icon" type="image/png" href="assets/images/favicon.png">
</head>

<body class="bg-f8f9fd">

    <!-- Preloader -->
    <?php
    include("./assets/components/pre-loader.php")
        ?>
    <!-- End Preloader -->

    <!-- Start Navbar Area -->
    <?php
    include("./assets/components/contact-side-bar.php")
        ?>
    <!-- End Navbar Area -->

    <!-- Start Menu Popup Area -->
    <?php
    include("./assets/components/sidebar-menu.php")
        ?>
    <!-- End Menu Popup Area -->

    <!-- Start Service Details Page Banner Area -->
    <div class="service-details-page-banner-area">
        <div class="container">
            <div class="row">
                <div class="col-lg-6 col-md-12">
                    <div class="content position-relative">
                        <h1 class="text-animation">
                            Brand <span>strategy</span>
                        </h1>
                        <p>
                            We help define your brand’s identity and create a roadmap for consistent growth,
                            positioning, and market presence.
                        </p>
                    </div>
                </div>
                <div class="col-lg-6 col-md-12">
                    <div class="image">
                        <img src="assets/images/services/service-details.jpg" alt="service-details-image">
                        <div class="info d-flex align-items-center">
                            <div class="number lh-1">
                                212<span>+</span>
                            </div>
                            <span class="d-block title">
                                Relevant work accomplished
                            </span>
                        </div>
                    </div>
                </div>
            </div>
            <hr>
        </div>
    </div>
    <!-- End Service Details Page Banner Area -->

    <!-- Start Works Process Area -->
    <div class="works-process-area ptb-150">
        <div class="container">
            <div class="row">
                <div class="col-lg-6 col-md-12">
                    <div class="works-process-content">
                        <h1>
                            Our workflow <span>strategy</span>
                        </h1>
                        <img src="assets/images/works-process.jpg" alt="works-process-image">
                    </div>
                </div>
                <div class="col-lg-6 col-md-12">
                    <div class="works-process-lines">
                        <div class="item position-relative">
                            <div
                                class="number d-flex align-items-center justify-content-center text-center rounded-circle">
                                01
                            </div>
                            <div class="icon position-relative">
                                <img src="assets/images/icons/tidal.png" alt="icon">
                                <img src="assets/images/icons/tidal2.svg" alt="icon">
                            </div>
                            <h3>
                                Ideation phase
                            </h3>
                            <p>
                                We begin by brainstorming and refining creative ideas that align with your brand vision.
                                This phase sets the foundation for a strategic and impactful execution.
                            </p>
                            <hr>
                        </div>
                        <div class="item position-relative">
                            <div
                                class="number d-flex align-items-center justify-content-center text-center rounded-circle">
                                02
                            </div>
                            <div class="icon position-relative">
                                <img src="assets/images/icons/codepen.svg" alt="icon">
                                <img src="assets/images/icons/codepen2.svg" alt="icon">
                            </div>
                            <h3>
                                Planning & strategy
                            </h3>
                            <p>
                                A well-defined roadmap ensures smooth project execution. We focus on research,
                                goal-setting, and structuring a clear strategy tailored to your objectives.
                            </p>
                            <hr>
                        </div>
                        <div class="item position-relative">
                            <div
                                class="number d-flex align-items-center justify-content-center text-center rounded-circle">
                                03
                            </div>
                            <div class="icon position-relative">
                                <img src="assets/images/icons/dhis.svg" alt="icon">
                                <img src="assets/images/icons/dhis2.svg" alt="icon">
                            </div>
                            <h3>
                                Execution & development
                            </h3>
                            <p>
                                Bringing ideas to life with precision and creativity. Our team works on design,
                                development, and content creation while ensuring quality and consistency.
                            </p>
                            <hr>
                        </div>
                        <div class="item position-relative">
                            <div
                                class="number d-flex align-items-center justify-content-center text-center rounded-circle">
                                04
                            </div>
                            <div class="icon position-relative">
                                <img src="assets/images/icons/tidal.png" alt="icon">
                                <img src="assets/images/icons/tidal2.svg" alt="icon">
                            </div>
                            <h3>
                                Review & optimization
                            </h3>
                            <p>
                                We analyze results, gather feedback, and make refinements to enhance performance.
                                Continuous improvement ensures long-term success and effectiveness.
                            </p>
                            <hr>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- End Works Process Area -->

    <!-- Start Case Studies Area -->
    <div class="case-studies-area bg-black pt-150 pb-125">
        <div class="container">
            <div class="creative-agency-section-title text-white">
                <div class="row align-items-center">
                    <div class="col-lg-8 col-md-12">
                        <div class="left-side">
                            <h2>
                                Highlighting Our <span>case studies</span>
                            </h2>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-12">
                        <div class="right-side top-0">
                            <a href="works.php" class="default-btn mt-0">
                                View Case Studies
                                <i class="ri-arrow-right-line"></i>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="case-studies-lines">
                <div class="item">
                    <div class="row">
                        <div class="col-lg-5 col-md-12">
                            <a href="work-single.php" class="image d-block">
                                <img src="assets/images/case-studies/case-study6.jpg" alt="case-study-image">
                            </a>
                        </div>
                        <div class="col-lg-7 col-md-12">
                            <div class="content position-relative">
                                <div
                                    class="number d-flex align-items-center justify-content-center text-center rounded-circle">
                                    01
                                </div>
                                <h3 class="fw-normal">
                                    <a href="work-single.php">
                                        Revamping e-commerce success
                                    </a>
                                </h3>
                                <p class="fw-medium">
                                    Redefined an online store's user experience, leading to increased conversions and
                                    customer retention.
                                </p>
                                <a href="work-single.php" class="link-btn d-flex align-items-center fw-medium">
                                    Read More <i class="ri-arrow-right-up-line"></i>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="item">
                    <div class="row">
                        <div class="col-lg-5 col-md-12">
                            <a href="work-single.php" class="image d-block">
                                <img src="assets/images/case-studies/case-study7.jpg" alt="case-study-image">
                            </a>
                        </div>
                        <div class="col-lg-7 col-md-12">
                            <div class="content position-relative">
                                <div
                                    class="number d-flex align-items-center justify-content-center text-center rounded-circle">
                                    02
                                </div>
                                <h3 class="fw-normal">
                                    <a href="work-single.php">
                                        Transforming saas user experience
                                    </a>
                                </h3>
                                <p class="fw-medium">
                                    Designed an intuitive interface for a SaaS platform, enhancing usability and client
                                    engagement.
                                </p>
                                <a href="work-single.php" class="link-btn d-flex align-items-center fw-medium">
                                    Read More <i class="ri-arrow-right-up-line"></i>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="item">
                    <div class="row">
                        <div class="col-lg-5 col-md-12">
                            <a href="work-single.php" class="image d-block">
                                <img src="assets/images/case-studies/case-study8.jpg" alt="case-study-image">
                            </a>
                        </div>
                        <div class="col-lg-7 col-md-12">
                            <div class="content position-relative">
                                <div
                                    class="number d-flex align-items-center justify-content-center text-center rounded-circle">
                                    03
                                </div>
                                <h3 class="fw-normal">
                                    <a href="work-single.php">
                                        Boosting digital agency growth
                                    </a>
                                </h3>
                                <p class="fw-medium">
                                    Implemented a data-driven marketing strategy, improving lead generation and brand
                                    visibility.
                                </p>
                                <a href="work-single.php" class="link-btn d-flex align-items-center fw-medium">
                                    Read More <i class="ri-arrow-right-up-line"></i>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- End Case Studies Area -->

    <!-- Start Footer Area -->
    <?php
    include("./assets/components/footer-two.php")
        ?>
    <!-- End Footer Area -->

    <!-- Link of JS files -->
    <?php
    include("./assets/components/script.php")
        ?>
    <!-- ========== GOOGLE TRANSLATE CONTAINER (HIDDEN) ========== -->
    <div id="google_translate_element" style="display:none;"></div>

    <script>
        // ========== GOOGLE TRANSLATE INITIALIZE ==========
        function loadGoogleTranslate() {
            new google.translate.TranslateElement({
                pageLanguage: 'en',
                includedLanguages: 'en,ur,fr,es,ar'
            }, 'google_translate_element');
        }
    </script>
    <script src="https://translate.google.com/translate_a/element.js?cb=loadGoogleTranslate"></script>

    <script>
        // ========== APPLY SAVED LANGUAGE ON EVERY PAGE ==========
        document.addEventListener("DOMContentLoaded", function () {
            const savedLang = localStorage.getItem("selectedLanguage");

            if (savedLang) {
                const checkExist = setInterval(() => {
                    const combo = document.querySelector(".goog-te-combo");
                    if (combo) {
                        combo.value = savedLang;
                        combo.dispatchEvent(new Event("change"));
                        clearInterval(checkExist);
                    }
                }, 400);
            }
        });
    </script>

</body>

</html>