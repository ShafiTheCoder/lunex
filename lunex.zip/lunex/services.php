<!DOCTYPE html>
<html lang="zxx">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Link of CSS files -->
    <?php
    include("./assets/components/links.php")
        ?>

    <title>Lunex - Creative Agency HTML Template</title>
    <link rel="icon" type="image/png" href="assets/images/favicon.png">
</head>

<body class="bg-f8f9fd">

    <!-- Preloader -->
    <?php
    include("./assets/components/pre-loader.php")
        ?>
    <!-- End Preloader -->

    <!-- Start Navbar Area -->
    <?php
    include("./assets/components/contact-side-bar.php")
        ?>
    <!-- End Navbar Area -->

    <!-- Start Menu Popup Area -->
    <?php
    include("./assets/components/sidebar-menu.php")
        ?>
    <!-- End Menu Popup Area -->

    <!-- Start Services Page Banner Area -->
    <div class="services-page-banner-area">
        <div class="container">
            <div class="content">
                <div class="row align-items-center">
                    <div class="col-lg-7 col-md-7">
                        <div class="left-side">
                            <span class="sub-title d-block">
                                Services
                            </span>
                            <h1 class="mb-0 text-animation">
                                Our creative <span>solutions</span>
                            </h1>
                        </div>
                    </div>
                    <div class="col-lg-5 col-md-5">
                        <div class="right-side">
                            <p>
                                Our creative solutions combine innovation and strategy to craft unique experiences that
                                drive growth and engagement.
                            </p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="image text-center">
                <img src="assets/images/services/service6.jpg" alt="service-image">
            </div>
        </div>
    </div>
    <!-- End Services Page Banner Area -->

    <!-- Start Services Area -->
    <div class="services-area ptb-150">
        <div class="container">
            <div class="services-list-style-two">
                <div class="item position-relative">
                    <div class="row align-items-center">
                        <div class="col-lg-6 col-md-5">
                            <h3>
                                <a href="service-single.php">
                                    Brand strategy
                                </a>
                            </h3>
                        </div>
                        <div class="col-lg-4 col-md-5">
                            <p>
                                We help define your brand’s identity and create a roadmap for consistent growth,
                                positioning, and market presence.
                            </p>
                        </div>
                        <div class="col-lg-2 col-md-2">
                            <div class="text-md-end">
                                <a href="service-single.php"
                                    class="link-btn d-inline-block position-relative text-center rounded-circle">
                                    <i class="ri-arrow-right-up-line"></i>
                                </a>
                            </div>
                        </div>
                    </div>
                    <a href="service-single.php" class="image d-block">
                        <img src="assets/images/services/service7.jpg" alt="service-image">
                    </a>
                </div>
                <div class="item position-relative">
                    <div class="row align-items-center">
                        <div class="col-lg-6 col-md-5">
                            <h3>
                                <a href="service-single.php">
                                    Creative design
                                </a>
                            </h3>
                        </div>
                        <div class="col-lg-4 col-md-5">
                            <p>
                                From logos to websites, our creative design solutions bring your brand to life with
                                visually stunning and user-centric designs.
                            </p>
                        </div>
                        <div class="col-lg-2 col-md-2">
                            <div class="text-md-end">
                                <a href="service-single.php"
                                    class="link-btn d-inline-block position-relative text-center rounded-circle">
                                    <i class="ri-arrow-right-up-line"></i>
                                </a>
                            </div>
                        </div>
                    </div>
                    <a href="service-single.php" class="image d-block">
                        <img src="assets/images/services/service8.jpg" alt="service-image">
                    </a>
                </div>
                <div class="item position-relative">
                    <div class="row align-items-center">
                        <div class="col-lg-6 col-md-5">
                            <h3>
                                <a href="service-single.php">
                                    Digital marketing
                                </a>
                            </h3>
                        </div>
                        <div class="col-lg-4 col-md-5">
                            <p>
                                We craft tailored digital marketing strategies that engage your audience, boost
                                conversions, & build brand loyalty across multiple platforms.
                            </p>
                        </div>
                        <div class="col-lg-2 col-md-2">
                            <div class="text-md-end">
                                <a href="service-single.php"
                                    class="link-btn d-inline-block position-relative text-center rounded-circle">
                                    <i class="ri-arrow-right-up-line"></i>
                                </a>
                            </div>
                        </div>
                    </div>
                    <a href="service-single.php" class="image d-block">
                        <img src="assets/images/services/service9.jpg" alt="service-image">
                    </a>
                </div>
                <div class="item position-relative">
                    <div class="row align-items-center">
                        <div class="col-lg-6 col-md-5">
                            <h3>
                                <a href="service-single.php">
                                    Web development
                                </a>
                            </h3>
                        </div>
                        <div class="col-lg-4 col-md-5">
                            <p>
                                Our expert web development team creates high-performance websites & applications that
                                enhance experience & functionality.
                            </p>
                        </div>
                        <div class="col-lg-2 col-md-2">
                            <div class="text-md-end">
                                <a href="service-single.php"
                                    class="link-btn d-inline-block position-relative text-center rounded-circle">
                                    <i class="ri-arrow-right-up-line"></i>
                                </a>
                            </div>
                        </div>
                    </div>
                    <a href="service-single.php" class="image d-block">
                        <img src="assets/images/services/service10.jpg" alt="service-image">
                    </a>
                </div>
                <div class="item position-relative">
                    <div class="row align-items-center">
                        <div class="col-lg-6 col-md-5">
                            <h3>
                                <a href="service-single.php">
                                    Social media management
                                </a>
                            </h3>
                        </div>
                        <div class="col-lg-4 col-md-5">
                            <p>
                                We manage & optimize your social media presence, creating engaging content & strategies
                                to grow your audience.
                            </p>
                        </div>
                        <div class="col-lg-2 col-md-2">
                            <div class="text-md-end">
                                <a href="service-single.php"
                                    class="link-btn d-inline-block position-relative text-center rounded-circle">
                                    <i class="ri-arrow-right-up-line"></i>
                                </a>
                            </div>
                        </div>
                    </div>
                    <a href="service-single.php" class="image d-block">
                        <img src="assets/images/services/service11.jpg" alt="service-image">
                    </a>
                </div>
                <div class="item position-relative">
                    <div class="row align-items-center">
                        <div class="col-lg-6 col-md-5">
                            <h3>
                                <a href="service-single.php">
                                    Content creation
                                </a>
                            </h3>
                        </div>
                        <div class="col-lg-4 col-md-5">
                            <p>
                                We develop compelling content, from copywriting to video production, designed to tell
                                your story & connect with your audience.
                            </p>
                        </div>
                        <div class="col-lg-2 col-md-2">
                            <div class="text-md-end">
                                <a href="service-single.php"
                                    class="link-btn d-inline-block position-relative text-center rounded-circle">
                                    <i class="ri-arrow-right-up-line"></i>
                                </a>
                            </div>
                        </div>
                    </div>
                    <a href="service-single.php" class="image d-block">
                        <img src="assets/images/services/service12.jpg" alt="service-image">
                    </a>
                </div>
            </div>
        </div>
    </div>
    <!-- End Services Area -->

    <!-- Start Works Process Area -->
    <div class="works-process-area pb-150">
        <div class="container">
            <div class="creative-agency-section-title">
                <div class="row align-items-center">
                    <div class="col-lg-8 col-md-6">
                        <div class="left-side">
                            <h2>
                                Our workflow <span class="text-primary">strategy</span>
                            </h2>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6">
                        <div class="right-side style-two">
                            <p>
                                Our workflow strategy ensures a seamless process from concept to execution. We focus on
                                efficiency, creativity, and precision to deliver outstanding results for every project.
                            </p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row justify-content-center">
                <div class="col-lg-7 col-md-12">
                    <div class="works-process-list">
                        <div class="item">
                            <div class="icon">
                                <img src="assets/images/icons/marketing.svg" alt="icon">
                            </div>
                            <h3>
                                Ideation phase
                            </h3>
                            <p>
                                We begin by brainstorming and refining creative ideas that align with your brand vision.
                                This phase sets the foundation for a strategic and impactful execution.
                            </p>
                        </div>
                        <div class="item">
                            <div class="icon">
                                <img src="assets/images/icons/seo-web.svg" alt="icon">
                            </div>
                            <h3>
                                Planning & strategy
                            </h3>
                            <p>
                                A well-defined roadmap ensures smooth project execution. We focus on research,
                                goal-setting, and structuring a clear strategy tailored to your objectives.
                            </p>
                        </div>
                        <div class="item">
                            <div class="icon">
                                <img src="assets/images/icons/continous-improvement.svg" alt="icon">
                            </div>
                            <h3>
                                Execution & development
                            </h3>
                            <p>
                                Bringing ideas to life with precision and creativity. Our team works on design,
                                development, and content creation while ensuring quality and consistency.
                            </p>
                        </div>
                        <div class="item">
                            <div class="icon">
                                <img src="assets/images/icons/content-marketing.svg" alt="icon">
                            </div>
                            <h3>
                                Review & optimization
                            </h3>
                            <p>
                                We analyze results, gather feedback, and make refinements to enhance performance.
                                Continuous improvement ensures long-term success and effectiveness.
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- End Works Process Area -->

    <!-- Start Features Area -->
    <div class="features-area bg-color pt-150 pb-125">
        <div class="container">
            <div class="row gx-md-0">
                <div class="col-lg-3 col-sm-6">
                    <div class="single-feature-item position-relative">
                        <div class="line"></div>
                        <h3>
                            Smart strategy
                        </h3>
                        <p>
                            We craft data-driven strategies tailored to your business goals, ensuring efficiency &
                            impactful results.
                        </p>
                    </div>
                </div>
                <div class="col-lg-3 col-sm-6">
                    <div class="single-feature-item position-relative">
                        <div class="line"></div>
                        <h3>
                            Seamless execution
                        </h3>
                        <p>
                            Our expert team transforms ideas into reality with precision, delivering high-quality
                            solutions on time.
                        </p>
                    </div>
                </div>
                <div class="col-lg-3 col-sm-6">
                    <div class="single-feature-item position-relative">
                        <div class="line"></div>
                        <h3>
                            Engaging design
                        </h3>
                        <p>
                            Aesthetic & user-friendly designs that captivate audiences & enhance brand identity.
                        </p>
                    </div>
                </div>
                <div class="col-lg-3 col-sm-6">
                    <div class="single-feature-item position-relative">
                        <div class="line"></div>
                        <h3>
                            Performance optimization
                        </h3>
                        <p>
                            We continuously analyze & refine solutions to maximize effectiveness & long-term success.
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- End Features Area -->

    <!-- Start Trusted Clients Area -->
    <div class="trusted-clients-area ptb-150">
        <div class="container">
            <div class="creative-agency-section-title">
                <div class="row align-items-center">
                    <div class="col-lg-8 col-md-6">
                        <div class="left-side">
                            <h2>
                                Our valued <span class="text-primary">clients</span>
                            </h2>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6">
                        <div class="right-side style-two">
                            <p>
                                We take pride in building strong relationships with our valued partners who trust us to
                                bring their visions to life. Our commitment to excellence and innovation has earned us
                                the confidence of businesses across various industries.
                            </p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="swiper trustedClientsSwiper">
                <div class="swiper-wrapper">
                    <div class="swiper-slide text-center">
                        <div class="item">
                            <img src="assets/images/partners/partner1.svg" alt="partner-image">
                        </div>
                    </div>
                    <div class="swiper-slide text-center">
                        <div class="item">
                            <img src="assets/images/partners/partner2.svg" alt="partner-image">
                        </div>
                    </div>
                    <div class="swiper-slide text-center">
                        <div class="item">
                            <img src="assets/images/partners/partner3.svg" alt="partner-image">
                        </div>
                    </div>
                    <div class="swiper-slide text-center">
                        <div class="item">
                            <img src="assets/images/partners/partner4.svg" alt="partner-image">
                        </div>
                    </div>
                    <div class="swiper-slide text-center">
                        <div class="item">
                            <img src="assets/images/partners/partner5.svg" alt="partner-image">
                        </div>
                    </div>
                </div>
                <div class="swiper-button-prev"></div>
                <div class="swiper-button-next"></div>
            </div>
        </div>
    </div>
    <!-- End Trusted Clients Area -->

    <!-- Start Footer Area -->
    <?php
    include("./assets/components/footer-two.php")
        ?>
    <!-- End Footer Area -->

    <!-- Link of JS files -->
    <?php
    include("./assets/components/script.php")
        ?>
    <!-- ========== GOOGLE TRANSLATE CONTAINER (HIDDEN) ========== -->
    <div id="google_translate_element" style="display:none;"></div>

    <script>
        // ========== GOOGLE TRANSLATE INITIALIZE ==========
        function loadGoogleTranslate() {
            new google.translate.TranslateElement({
                pageLanguage: 'en',
                includedLanguages: 'en,ur,fr,es,ar'
            }, 'google_translate_element');
        }
    </script>
    <script src="https://translate.google.com/translate_a/element.js?cb=loadGoogleTranslate"></script>

    <script>
        // ========== APPLY SAVED LANGUAGE ON EVERY PAGE ==========
        document.addEventListener("DOMContentLoaded", function () {
            const savedLang = localStorage.getItem("selectedLanguage");

            if (savedLang) {
                const checkExist = setInterval(() => {
                    const combo = document.querySelector(".goog-te-combo");
                    if (combo) {
                        combo.value = savedLang;
                        combo.dispatchEvent(new Event("change"));
                        clearInterval(checkExist);
                    }
                }, 400);
            }
        });
    </script>

</body>

</html>