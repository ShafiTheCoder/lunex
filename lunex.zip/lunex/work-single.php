<!DOCTYPE html>
<html lang="zxx">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Link of CSS files -->
    <?php
    include("./assets/components/links.php")
        ?>


    <title>Lunex - Creative Agency HTML Template</title>
    <link rel="icon" type="image/png" href="assets/images/favicon.png">
</head>

<body class="bg-f8f9fd">

    <!-- Preloader -->
    <?php
    include("./assets/components/pre-loader.php")
        ?>
    <!-- End Preloader -->

    <!-- Start Navbar Area -->
    <?php
    include("./assets/components/contact-side-bar.php")
        ?>
    <!-- End Navbar Area -->

    <!-- Start Menu Popup Area -->
    <?php
    include("./assets/components/sidebar-menu.php")
        ?>
    <!-- End Menu Popup Area -->

    <!-- Start Project Details Area -->
    <div class="project-details-area pb-150">
        <div class="container">
            <div class="project-details-content">
                <div class="row align-items-center">
                    <div class="col-lg-8 col-md-12">
                        <div class="title">
                            <span class="sub-title d-block">
                                Work details
                            </span>
                            <h1 class="mb-0 text-animation">
                                Brand identity & <span>web design</span>
                            </h1>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-12">
                        <div class="info">
                            <span class="d-block fw-medium">
                                Category
                            </span>
                            <h3 class="mb-0">
                                Web Design
                            </h3>
                        </div>
                    </div>
                </div>
            </div>
            <div class="text-center" data-cue="slideInUp">
                <img src="assets/images/projects/project-details.jpg" alt="project-details-image">
            </div>
            <div class="project-details-info d-md-flex align-items-center justify-content-between" data-cue="slideInUp">
                <div>
                    <h3>
                        Client
                    </h3>
                    <span class="d-block fw-medium">
                        Sarah Thompson
                    </span>
                </div>
                <div>
                    <h3>
                        Category
                    </h3>
                    <span class="d-block fw-medium">
                        Web Design
                    </span>
                </div>
                <div>
                    <h3>
                        Website
                    </h3>
                    <a href="#" target="_blank" class="d-inline-block position-relative fw-medium">
                        https://lunex.com/ <i class="ri-arrow-right-up-line"></i>
                    </a>
                </div>
                <div>
                    <h3>
                        Project Timeline
                    </h3>
                    <span class="d-block fw-medium">
                        1.5 months
                    </span>
                </div>
                <div>
                    <h3>
                        Service we offer
                    </h3>
                    <span class="d-block fw-medium">
                        UI/UX
                    </span>
                </div>
            </div>
        </div>
    </div>
    <!-- End Project Details Area -->

    <!-- Start Design Principles Area -->
    <div class="design-principles-area ptb-150">
        <div class="container">
            <div class="creative-agency-section-title text-white">
                <div class="left-side">
                    <h2 class="text-animation">
                        Core design <span>principles</span>
                    </h2>
                </div>
            </div>
            <div class="design-principles-content" data-cues="slideInUp">
                <div class="row">
                    <div class="col-lg-7 col-md-12">
                        <div class="image">
                            <img src="assets/images/design-principles.jpg" alt="design-principles-image">
                        </div>
                    </div>
                    <div class="col-lg-5 col-md-12">
                        <div class="content">
                            <p class="fw-medium">
                                Our core design principles are rooted in creating visually stunning and user-friendly
                                solutions. We emphasize clarity, consistency, and functionality at every stage, ensuring
                                that each design element enhances the user experience, fosters engagement, and aligns
                                seamlessly with your brand’s unique identity and goals.
                            </p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="design-principles-list" data-cues="slideInUp">
                <div class="item">
                    <div class="row">
                        <div class="col-lg-7 col-md-12">
                            <div class="title d-flex align-items-center">
                                <div
                                    class="number rounded-circle text-center d-flex align-items-center justify-content-center">
                                    01
                                </div>
                                <h3 class="mb-0">
                                    Clarity
                                </h3>
                            </div>
                        </div>
                        <div class="col-lg-5 col-md-12">
                            <div class="content">
                                <p class="fw-medium">
                                    Every design element is crafted with simplicity in mind, ensuring users can easily
                                    understand and navigate the interface. We remove unnecessary complexity, so the
                                    message and functionality are clear and intuitive.
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="item">
                    <div class="row">
                        <div class="col-lg-7 col-md-12">
                            <div class="title d-flex align-items-center">
                                <div
                                    class="number rounded-circle text-center d-flex align-items-center justify-content-center">
                                    02
                                </div>
                                <h3 class="mb-0">
                                    Consistency
                                </h3>
                            </div>
                        </div>
                        <div class="col-lg-5 col-md-12">
                            <div class="content">
                                <p class="fw-medium">
                                    Consistency in design is key to building a recognizable and trusted brand. We
                                    maintain uniformity in typography, colors, and layout to create a cohesive and
                                    predictable user experience across all platforms and devices.
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="item">
                    <div class="row">
                        <div class="col-lg-7 col-md-12">
                            <div class="title d-flex align-items-center">
                                <div
                                    class="number rounded-circle text-center d-flex align-items-center justify-content-center">
                                    03
                                </div>
                                <h3 class="mb-0">
                                    Functionality
                                </h3>
                            </div>
                        </div>
                        <div class="col-lg-5 col-md-12">
                            <div class="content">
                                <p class="fw-medium">
                                    We prioritize creating user-friendly and efficient designs. Each element is
                                    strategically placed and optimized to enhance usability, allowing users to
                                    accomplish their goals with ease, whether it's navigating a website or interacting
                                    with a product.
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- End Design Principles Area -->

    <!-- Start Mockups Area -->
    <div class="mockups-area pt-150 pb-125">
        <div class="container">
            <div class="row" data-cues="slideInUp">
                <div class="col-12">
                    <div class="single-mockup-item text-center">
                        <img src="assets/images/mockups/mockup1.jpg" alt="mockup-image">
                    </div>
                </div>
                <div class="col-6">
                    <div class="single-mockup-item text-center">
                        <img src="assets/images/mockups/mockup2.jpg" alt="mockup-image">
                    </div>
                </div>
                <div class="col-6">
                    <div class="single-mockup-item text-center">
                        <img src="assets/images/mockups/mockup3.jpg" alt="mockup-image">
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- End Mockups Area -->

    <!-- Start Impact Area -->
    <div class="impact-area pb-150">
        <div class="container">
            <div class="creative-agency-section-title">
                <div class="left-side">
                    <h2 class="text-animation">
                        Impact we've <span class="text-primary">made</span>
                    </h2>
                </div>
            </div>
            <div class="impact-list" data-cues="slideInUp">
                <div class="item">
                    <div class="row align-items-center">
                        <div class="col-lg-5 col-md-4">
                            <div class="icon rounded-circle d-flex align-items-center justify-content-center">
                                <img src="assets/images/icons/touch-id.svg" alt="icon">
                            </div>
                        </div>
                        <div class="col-lg-4 col-md-4">
                            <div class="content">
                                <h3 class="fw-normal">
                                    30%
                                </h3>
                                <span class="d-block">
                                    Driving engagement
                                </span>
                            </div>
                        </div>
                        <div class="col-lg-3 col-md-4">
                            <p>
                                Through innovative designs and strategies, we captivate audiences, leading to higher
                                interaction and meaningful connections with the brand.
                            </p>
                        </div>
                    </div>
                </div>
                <div class="item">
                    <div class="row align-items-center">
                        <div class="col-lg-5 col-md-4">
                            <div class="icon rounded-circle d-flex align-items-center justify-content-center">
                                <img src="assets/images/icons/economic-growth.svg" alt="icon">
                            </div>
                        </div>
                        <div class="col-lg-4 col-md-4">
                            <div class="content">
                                <h3 class="fw-normal">
                                    40%
                                </h3>
                                <span class="d-block">
                                    Enhancing user experience
                                </span>
                            </div>
                        </div>
                        <div class="col-lg-3 col-md-4">
                            <p>
                                By focusing on clarity and usability, we create intuitive platforms that increase user
                                satisfaction and promote brand loyalty.
                            </p>
                        </div>
                    </div>
                </div>
                <div class="item">
                    <div class="row align-items-center">
                        <div class="col-lg-5 col-md-4">
                            <div class="icon rounded-circle d-flex align-items-center justify-content-center">
                                <img src="assets/images/icons/dissatisfaction.svg" alt="icon">
                            </div>
                        </div>
                        <div class="col-lg-4 col-md-4">
                            <div class="content">
                                <h3 class="fw-normal">
                                    25%
                                </h3>
                                <span class="d-block">
                                    Boosting business growth
                                </span>
                            </div>
                        </div>
                        <div class="col-lg-3 col-md-4">
                            <p>
                                Our tailored solutions have helped businesses scale by improving their digital presence,
                                increasing conversions, and fostering long-term success.
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- End Impact Area -->

    <!-- Start Footer Area -->
    <?php
    include("./assets/components/footer-two.php")
        ?>
    <!-- End Footer Area -->

    <!-- Link of JS files -->
    <?php
    include("./assets/components/script.php")
        ?>

    <!-- ========== GOOGLE TRANSLATE CONTAINER (HIDDEN) ========== -->
    <div id="google_translate_element" style="display:none;"></div>

    <script>
        // ========== GOOGLE TRANSLATE INITIALIZE ==========
        function loadGoogleTranslate() {
            new google.translate.TranslateElement({
                pageLanguage: 'en',
                includedLanguages: 'en,ur,fr,es,ar'
            }, 'google_translate_element');
        }
    </script>
    <script src="https://translate.google.com/translate_a/element.js?cb=loadGoogleTranslate"></script>

    <script>
        // ========== APPLY SAVED LANGUAGE ON EVERY PAGE ==========
        document.addEventListener("DOMContentLoaded", function () {
            const savedLang = localStorage.getItem("selectedLanguage");

            if (savedLang) {
                const checkExist = setInterval(() => {
                    const combo = document.querySelector(".goog-te-combo");
                    if (combo) {
                        combo.value = savedLang;
                        combo.dispatchEvent(new Event("change"));
                        clearInterval(checkExist);
                    }
                }, 400);
            }
        });
    </script>


</body>

</html>